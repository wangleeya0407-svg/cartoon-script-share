# 五步流水线：命令、参数、产物

输入只有一段语音（或一段带声音的视频），输出一条 1920×1080 的知识动画成片。

```
语音/视频
  ↓ ① 转写      transcribe.py    → talk/<slug>.json
  ↓ ② 繁简归一   t2s.py          → talk/<slug>-cn.json
  ↓ ③ 校订       mkoverride.mjs  → 校订表；course-fix.mjs → config.json
  ↓ ④ 生成       build-course.mjs → index.html
  ↓ ⑤ 渲染验收   hyperframes + ffmpeg
```

工程目录约定（`<slug>` 为课程短名，如 `api-course`）：

```
<工作区>/
├── talk/<slug>.json              ① ② 的产物
├── pipeline/override-src/<slug>.json   ③ 的输入（人工写）
├── <slug>/
│   ├── assets/
│   │   ├── mascot/*.png          米亚老师 IP 形象 7 张
│   │   ├── gsap.min.js
│   │   └── voice.m4a             音轨（config 里按相对路径引用）
│   ├── config.json               ③ 产物
│   ├── index.html                ④ 产物
│   ├── scenes.json               分镜表（人工写）
│   └── run.sh                    一条命令跑 ①②③④
```

---

## ① 转写

```bash
python3 <SKILL>/scripts/transcribe.py <音频> --model small --out talk/<slug>
```

| 参数 | 说明 |
|---|---|
| `--model` | 模型名（`small` / `medium`）或本地目录路径（如 `models/faster-whisper-small`） |
| `--out` | 输出前缀，产物是 `.json` / `.srt` / `.txt` |
| `--lang` | 默认 `zh` |

产物 `<slug>.json` 的结构：`{ lines: [{ start, end, text, words: [{t, s, e}] }] }`。
`words` 是词级时间戳，逐词高亮和字幕重排全靠它 —— **别删**。

耗时参考：`small` 模型约 1 分钟转 6 分钟音频。

---

## ② 繁简归一

```bash
python3 <SKILL>/scripts/t2s.py talk/<slug>.json --out talk/<slug>-cn.json
```

依赖 `zhconv`。输出会打印「繁体行归一 N」。**N 大于 0 是常态**（长音频后半段）。

---

## ③ 校订 + 生成 config

写校订稿 `pipeline/override-src/<slug>.json`（格式见 `caption-rules.md`），然后：

```bash
# 3a 行号 → 时间锚点
node <SKILL>/scripts/mkoverride.mjs talk/<slug>-cn.json \
  pipeline/override-src/<slug>.json --out pipeline/override-<slug>.json

# 3b 生成 config
node <SKILL>/scripts/course-fix.mjs talk/<slug>-cn.json \
  --start 0 --end <时长秒> \
  --out <slug>/config.json --out-dir <slug> \
  --audio assets/voice.m4a \
  --override pipeline/override-<slug>.json \
  --scenes <slug>/scenes.json \
  --base false \
  --chapter "第 05 讲 · API 入门" \
  --title "什么叫 API" \
  --brand "米亚老师 AI 课程"
```

| 参数 | 说明 |
|---|---|
| `--start` / `--end` | 时间窗口（掐头去尾用），一般 `0` 到音频总长 |
| `--out-dir` | 工程目录，config 会写进去，同时准备资源 |
| `--audio` | **相对工程目录**的路径，固定 `assets/voice.m4a` |
| `--base false` | 关掉第一课手写的 S1–S6。**讲别的主题必须传 false**，否则会混进「发动机 / 汽车 / 司机」那套画面 |
| `--chapter` | 页眉右上，如「第 04 讲 · 一人公司」 |
| `--title` | 课程标题 |
| `--brand` | 页眉左上品牌，固定「米亚老师 AI 课程」 |

输出会打印 `校订 N 条 ｜ 覆盖 M/M 行` —— **两个数必须都等于转写行数**。

---

## ④ 生成合成页

```bash
node <SKILL>/scripts/build-course.mjs <slug>/config.json
```

打印：`画幅 1920×1080 ｜ 时长 xs ｜ 场景 N ｜ 字幕 M 行 / K 词 ｜ 时间线指令 T 条`。
场景数要和 `scenes.json` 长度一致（`base: false` 时）。

---

## ⑤ 渲染与验收

**先抽帧看画面，再渲染整片。** 这一步能省掉 90% 的返工。

```bash
# 5a lint
npx hyperframes check <slug>

# 5b 抽关键帧（一次最多 5 张，分批）
npx hyperframes check <slug> --at 0.5,6,12,17,26 --snapshots
# 图落在 <slug>/.hyperframes/artifacts/snapshots/<uuid>/frame-XX-at-Ys.png

# 5c 渲染（必须分段捕获 + 2 worker）
bash <SKILL>/scripts/render.sh <slug> "课程名_成片.mp4"

# 5d 验收
bash <SKILL>/scripts/verify.sh <slug> "<slug>/课程名_成片.mp4" <预期时长>
```

| 命令 | 耗时参考 | 用途 |
|---|---|---|
| `check` | 20–60s | 排版/对比度/字号/字幕停留 lint |
| `check --snapshots` | 30–90s | 直接出关键帧图片，**比渲染快几十倍** |
| `render` | 3s / 分钟成片 | 出整片 |

`check` 的合理预期：**0 error，3–8 warning**。
warning 一般分两类：
- `composition_file_too_large` / `nested_structure_needs_subcomposition` —— 结构性提示，**不影响成片，不用管**。
- `line_unread` —— 字幕停留低于下限。能从分镜调就调（把元素 `at` 提前），
  调不动的（说话人自己语速太快）**认了**，加字只会更糟。

---

## 环境依赖

| 依赖 | 说明 |
|---|---|
| `hyperframes` | `npx hyperframes`，渲染内核 |
| `ffmpeg` / `ffprobe` | 抽音轨、抽帧、压缩 |
| `faster-whisper` + `ctranslate2` | 本地转写，不联网 |
| `zhconv` | 繁简归一 |
| `gsap.min.js` | 已在 `assets/`，无需下载 |

全部本地运行，**断网也能出片**（除了 `npx` 首次拉包）。
