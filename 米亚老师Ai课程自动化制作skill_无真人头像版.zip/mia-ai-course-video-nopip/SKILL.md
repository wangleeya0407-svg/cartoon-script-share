---
name: mia-ai-course-video-nopip
display_name: 米亚老师Ai课程自动化制作skill（无真人头像版）
description: 米亚老师Ai课程自动化制作Skill（无真人头像版，画面只用卡通形象，不放真人画中画）——把一段语音（或一段带声音的视频/录屏）自动做成 1920×1080 的知识动画课程成片：本地转写、繁简归一、逐行校订字幕、数据驱动分镜、GSAP 动画、渲染输出，全程不联网。当用户说「把这个视频/音频也做一下」「剪辑成我要的课程视频」「按之前那套流程做」「课程视频自动化」「用米亚老师Ai课程自动化制作skill」「做成米亚老师那种知识动画」「加个人IP形象/角标/防搬运」，或丢来一个 mp4/mp3 说「这个也剪一下」时使用。自带米亚老师七张 IP 卡通形象（四张半身 + 三张头像，自动铺满画面）、GSAP、转写与生成器脚本、字幕与排版规则、验收清单。
agent_created: true
---

# 米亚老师Ai课程自动化制作Skill（无真人头像版）

> 本版本**不放真人圆形头像小窗**：输入是视频也只取声音，画面全部由卡通形象 + 动画构成。

把一段语音变成一条**有 IP 属性、有节奏、字幕零错字**的横屏知识动画成片。
输入只要声音，画面全部重新生成 —— 源视频只用来读懂内容结构，不进成片。

## 什么时候用

- 「@某个视频/音频 这个也做一下」「这个也帮我剪成我要的视频」
- 「按之前那套流程做」「课程视频自动化」「做成米亚老师那种知识动画」
- 「给视频加我的卡通形象 / 加角标 / 防搬运」
- 「字幕有错字 / 断词 / 太碎，重做一下」

用户默认用语音下指令，口语化、可能只说「这个也做一下」+ 一个文件路径。
看到这种就把文件接过来直接开工，不用反问。

## 用户的硬性要求（不可妥协，逐条守住）

1. **必须本人出镜感，形象要多用**：三层米亚老师 IP 形象 —— 背景底纹 3 处（0.075）/ 右上角标（表情随场景轮换）/ 章节卡·金句页·结尾卡自动放半身大图。详见下方「米亚老师形象怎么铺」。
2. **防搬运**：IP 形象埋在画面里，裁切截图也去不掉；角标标「原创」。
3. **首帧必须是完整封面**：平台抽第一帧当封面，所有元素 `t=0` 就在位，**不许从 opacity 0 淡入**。
4. **字幕要干净**：ASR 错字必须清零（专有名词、繁简、同音字），不许跨行断词，超 24 视觉宽或 6.2 秒必须拆。
5. **字号下限 28px**（1080 短边的 2.6%），小字会被 check 标红。
6. **宁可说实话也不假装完成**：验收要抽帧看真实成片，不靠纸面判断。
7. **只输出文字路径 + 状态说明**，不返回图片视频文件。

## 米亚老师形象怎么铺

素材在 `assets/mascot/`，七张，全部透明底：

| 素材名 | 形象 | 默认用在 |
|---|---|---|
| `mia-talk` | 半身 · 双手摊开讲解 | 首场景封面（站左） |
| `mia-point` | 半身 · 手指向左 | 章节卡 / 金句页（站右，手指画面中央） |
| `mia-ok` | 半身 · 比 OK | 章节卡 / 金句页轮换；背景底纹左下 |
| `mia-heart` | 半身 · 双手比心 | 结尾卡（站左） |
| `mia-smile` | 头像 · 微笑 | 右上角标（首帧） |
| `mia-wink` | 头像 · 眨眼 | 右上角标轮换；背景底纹左上 |
| `mia-laugh` | 头像 · 闭眼大笑 | 右上角标轮换；背景底纹右下 |

**默认全自动，分镜里什么都不写也会铺满：**

- 底纹三处 + 角标全片常驻；角标每换一个场景换一次表情（微笑 → 眨眼 → 大笑）。
- `chapter` / `punch` / `end` 三种留白多的版式，没写 `ip` 就自动放半身大图：首场景 `mia-talk`、结尾 `mia-heart`、中间按 `mia-point → mia-ok → mia-talk` 轮换，左右交替。
- `quad` / `list` / `vs` / `chain` 内容铺满全宽，不自动放大图（会压内容），靠底纹和角标保持出镜。

**想手动指定：** 场景里写 `"ip": "mia-ok"`，可不写 `ipStyle`（自动按高 400px 站位）；
写 `"ip": false` 关掉这一场；config 写 `"ipAuto": false` 全片关掉自动铺；`"ipHeight": 440` 统一调大图高度。
旧素材名 `ip-wave` 等仍可用，会自动映射到对应的米亚老师形象。

## 五步流水线

```
语音/视频
 ① 转写      scripts/transcribe.py   → talk/<slug>.json
 ② 繁简归一   scripts/t2s.py          → talk/<slug>-cn.json
 ③ 校订      scripts/mkoverride.mjs + scripts/course-fix.mjs → <slug>/config.json
 ④ 生成      scripts/build-course.mjs → <slug>/index.html
 ⑤ 渲染验收   hyperframes check / render + ffmpeg
```

**先看画面再渲染。** `check --snapshots` 抽帧比渲染整片快几十倍，能拦住 90% 的返工。

## 开工流程

### 1. 建工程

```bash
bash <SKILL>/scripts/scaffold_course.sh <slug> <音频或视频路径> "第 05 讲 · 主题" "课程标题"
```

生成 `<slug>/assets/`（mascot + gsap + voice.m4a）、`<slug>/scenes.json` 模板、`<slug>/run.sh`。

### 2. 转写

```bash
python3 <SKILL>/scripts/transcribe.py <slug>/assets/voice.m4a --model small --out talk/<slug>
```

`small` 模型约 1 分钟转 6 分钟音频。想用本地模型就传目录路径。

### 2b. 没有转写模型、但用户给了文字稿（更准，推荐）

用户粘贴口播文案 / 剪映导出字幕时，**不转写，直接按停顿对时间**：

```bash
python3 <SKILL>/scripts/align-script.py <slug>/assets/voice.m4a script.txt --out <slug>/transcript-cn.json
echo '[]' > <slug>/override-src.json      # 文字就是原稿，不需要校订
```

原理：静音检测切出语音段 → 分句按音节数动态规划装进各段 → 段内按音节分配逐词时间。
实测 45 秒口播 29 句全部对上（与人工对齐偏差 < 0.3s）。对不上就调 `--noise` / `--min-pause`。
然后跳到第 4 步写分镜（`run.sh` 检测到没有 transcript.json 会自动跳过繁简归一）。

**禁止用占位分镜交差**：分镜必须逐句对着口播文字写（标题、要点、对比、金句都来自原话），
拿不到文字（既不能转写、用户也没给稿）就停下来要文字稿，不要先拿模板场景渲染。

### 3. 通读全文，写校订稿

**这一步是整个流程最花时间、也最决定成败的一步。** 必须逐行读完 35–113 行转写。

- 先跑 `t2s.py` 繁简归一（whisper 后半段会整段吐繁体，顺序不能反）
- 写 `pipeline/override-src/<slug>.json`，**每一行都要覆盖**，跨行断词用 `span`
- ASR 错词高频库：`揭露→接入`、`设计到→涉及到`、`向→像`、`艺人公司→一人公司`、`币环→闭环`

详细格式、视觉宽算法、断词判定见 **`references/caption-rules.md`**。

### 4. 写分镜

按语音时间轴排 12–29 场，元素 `at` 直接对转写时间。

七种版式（`chapter` / `quad` / `punch` / `list` / `vs` / `chain` / `end`）的完整字段、
时间规则、密度参考见 **`references/scene-types.md`**。

关键约束：
- 每场第一个元素的 `at` **不得晚于 `start + 1.5s`**（否则露空窗，check 查不出来）
- 金句页 `pw-kicker` 到 `pw-line` 间隔 **≤ 0.8 秒**
- `quad` 必须正好 4 个 item；`chain` 3–4 个节点最稳
- 结尾卡第二行起必须加 `"cls": "sm"`

### 5. 生成 + 抽帧检查

```bash
bash <slug>/run.sh                       # ①②③④ 一条命令
npx hyperframes check <slug>             # lint，目标 0 error
npx hyperframes check <slug> --at 1.5,17,43,72 --snapshots   # 抽帧，一次最多 5 张
```

逐个核对关键帧，重点看：**空窗、压字、溢出、两栏不等高、首帧完整性**。

### 6. 渲染 + 压缩 + 验收

```bash
bash <SKILL>/scripts/render.sh <slug> "课程名_成片.mp4"
bash <SKILL>/scripts/verify.sh <slug> "<slug>/课程名_成片.mp4" <预期时长>
```

渲染**必须** `HF_SEGMENTED_CAPTURE=true ... -w 2`，4 worker 长片会在 70% 掉帧。

从成片 mp4 抽 8–11 帧再核一遍（`verify.sh` 会抽），确认无黑帧、无缺元素。

## 目录结构

```
mia-ai-course-video-nopip/
├── SKILL.md
├── scripts/
│   ├── scaffold_course.sh   建工程
│   ├── align-script.py      文字稿 + 音频 → 带时间字幕（无转写模型时用）
│   ├── transcribe.py        转写（faster-whisper 词级时间戳）
│   ├── t2s.py               繁简归一
│   ├── mkoverride.mjs       行号校订稿 → 时间锚点校订表
│   ├── course-fix.mjs       术语替换 + 校订 + 出 config
│   ├── build-course.mjs     数据驱动生成器（7 种版式 + IP 三层 + 自动铺形象）
│   ├── render.sh            渲染 + 压缩 + 参数自检
│   ├── verify.sh            抽帧验收（不走网络）
│   └── verify.mjs           原版验收（走网络，断网时改用 verify.sh）
├── assets/
│   ├── gsap.min.js
│   └── mascot/              米亚老师 7 张：mia-talk / mia-point / mia-ok / mia-heart / mia-smile / mia-wink / mia-laugh
└── references/
    ├── pipeline.md          五步详解：命令、参数、产物
    ├── scene-types.md       七种版式字段与时间规则
    ├── caption-rules.md     校订稿格式、视觉宽算法、断词判定、ASR 错词库
    ├── pitfalls.md          26 条踩坑：症状 → 根因 → 解法
    ├── checklist.md         交付验收清单（含自检脚本）
    └── cases.md             五支已交付片子的规模与节奏校准
```

## 遇到问题先查

- 画面空了 / 压字 / 溢出 / 首帧缺元素 → **`references/pitfalls.md`**
- 字幕断词、超宽、碎屏、错字 → **`references/caption-rules.md`**
- 场景排不下、字段不确定 → **`references/scene-types.md`**
- 参数报错、路径找不到 → **`references/pipeline.md`**
- 不确定节奏快慢、场景数 → **`references/cases.md`**

## 交付话术

只给文字路径 + 实测数字：

```
<slug>/课程名_成片.mp4   1920×1080 / 30fps / 3316 帧 / 110.55s / 8.7MB / aac 音轨
```

再补三句：**修了什么、为什么修、还有几条 warning 改不掉**。不返回图片和视频。
