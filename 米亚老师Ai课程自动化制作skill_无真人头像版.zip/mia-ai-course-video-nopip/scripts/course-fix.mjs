#!/usr/bin/env node
/**
 * course-fix.mjs — 把长课程转写裁成一段，并修正专有名词
 *
 * 为什么需要：
 *   1) Whisper 对 WorkBuddy / Codex / DeepSeek 这类专有名词识别极不稳定，
 *      同一条视频里会出现 Vocabody / Walkerbody / bockbody / cordiac / 扣带格式 等十几种写法。
 *   2) 逐词高亮要求「一个词一个时间块」，英文名常被拆碎（C + odex），必须先合并，
 *      否则字幕里会出现 C 和 odex 两个高亮块。
 *
 * 用法：
 *   node pipeline/course-fix.mjs talk/course.json --start 0 --end 52.7 --out course/config.json
 */

import fs from "node:fs";
import process from "node:process";

/* ---------- 参数 ---------- */
const argv = process.argv.slice(2);
const srcPath = argv[0] || "talk/course.json";
const getArg = (name, fallback) => {
  const i = argv.indexOf(name);
  return i >= 0 && argv[i + 1] != null ? argv[i + 1] : fallback;
};
const T_START = Number(getArg("--start", 0));
const T_END = Number(getArg("--end", 52.7));
const OUT = getArg("--out", "course/config.json");
const TITLE = getArg("--title", "新手入门课 · 大模型、工具和你");
const BRAND = getArg("--brand", "米亚老师 AI 课程");

const raw = JSON.parse(fs.readFileSync(srcPath, "utf8"));

/* ---------- 专有名词修正表 ----------
 * key 是「语音识别出来的各种错写」，value 是唯一正确写法。
 * 匹配时忽略大小写、忽略首尾标点。
 */
const TERM_MAP = [
  // WorkBuddy（ASR 错写最多的一个，十来种变体）
  ["vocabody", "WorkBuddy"],
  ["vogabody", "WorkBuddy"],
  ["walkerbody", "WorkBuddy"],
  ["bockbody", "WorkBuddy"],
  ["workbody", "WorkBuddy"],
  ["workbuddy", "WorkBuddy"],
  ["我个巴底", "WorkBuddy"],
  ["我个八点", "WorkBuddy"],
  ["我个八底", "WorkBuddy"],
  ["什么个八点", "WorkBuddy"],
  // Codex
  ["codex", "Codex"],
  ["cordiac", "Codex"],
  ["cored ex", "Codex"],
  ["coredex", "Codex"],
  ["扣带格式", "Codex"],
  ["扣带个四", "Codex"],
  ["扩大格式", "Codex"],
  // DeepSeek
  ["deepsync", "DeepSeek"],
  ["deepsinger", "DeepSeek"],
  ["deepsick", "DeepSeek"],
  ["deepseek", "DeepSeek"],
  // 文字大模型
  ["dobo", "豆包"],
  ["gbd", "GPT"],
  ["kimi", "Kimi"],
  ["统一千万", "通义千问"],
  ["統一千萬", "通义千问"],
  ["统千问", "通义千问"],
  ["ogabody", "WorkBuddy"],
  ["前文半功", "通义、文心"],
  ["切換辦公", "通义、文心"],
  ["切换办公", "通义、文心"],
  ["豆包工作", "豆包、通义"],
  // 视频大模型
  ["saturn是2.0", "Sora 2.0"],
  ["saturn 是 2.0", "Sora 2.0"],
  ["gimmon的2.5", "Gemini 2.5"],
  ["gimmon 的 2.5", "Gemini 2.5"],
  ["karin", "可灵"],
  ["solar", "Veo"],
  ["minimax", "MiniMax"],
  // 图片大模型
  ["gimmon5.0", "Gemini 5.0"],
  ["gimmon 5.0", "Gemini 5.0"],
  ["image内举", "Image"],
  ["香蕉不难", "Nano Banana"],
  ["mategeania", "Meta GenAI"],
  ["通异万象", "通义万相"],
  ["万象", "万相"],
  // 语音大模型
  ["训非", "讯飞"],
  // 其他
  ["混源", "混元"],
  ["难波万", "Number One"],
  ["山泽的关系", "三者的关系"],
  ["揭示", "接入"],
  ["揭露", "接入"],
  ["做稳制", "做文字"],
  ["凌晨本", "零成本"],
  ["卵建开发", "软件开发"],
];

const stripPunct = (s) => String(s || "").replace(/^[\s，。、；：,.!?;:]+|[\s，。、；：,.!?;:]+$/g, "");

/**
 * 修正单个词里的专有名词。
 * 先整词直配（快、也不会误伤），再退化为子串替换——
 * ASR 常把「Vocabody，Codex」吐成一个词块，整词匹配兜不住。
 * 首尾标点原样保留，否则字幕会丢逗号或黏连。
 */
function fixTerm(word) {
  const orig = String(word || "");
  const core = stripPunct(orig);
  if (!core) return null;

  const lead = (orig.match(/^[\s，。、；：,.!?;:]*/) || [""])[0];
  const tail = (orig.match(/[\s，。、；：,.!?;:]*$/) || [""])[0];

  const lower = core.toLowerCase().replace(/\s+/g, "");
  for (const [wrong, right] of TERM_MAP) {
    if (lower === wrong.replace(/\s+/g, "")) return lead + right + tail;
  }

  let out = orig;
  let hit = false;
  for (const [wrong, right] of TERM_MAP) {
    const pat = wrong.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s*");
    const re = new RegExp(pat, "gi");
    if (re.test(out)) {
      out = out.replace(re, right);
      hit = true;
    }
  }
  return hit ? out : null;
}

/* ---------- 合并被拆碎的英文/专有名词 ---------- */
const LATIN = /[A-Za-z0-9]/;

function mergeFragments(words) {
  const out = [];
  for (const w of words) {
    const prev = out[out.length - 1];
    const curCore = stripPunct(w.t);
    const prevCore = prev ? stripPunct(prev.t) : "";
    // 相邻两段都是纯英文数字、且间隔很短 → 认为是同一个词被拆碎
    const bothLatin =
      curCore && prevCore && LATIN.test(curCore[0]) && LATIN.test(prevCore[0]) &&
      /^[A-Za-z0-9，。、；：,.!?;:]*$/.test(curCore) && /^[A-Za-z0-9，。、；：,.!?;:]*$/.test(prevCore);
    if (bothLatin && w.s - prev.e < 0.6) {
      prev.t = prev.t + w.t;
      prev.e = w.e;
      continue;
    }
    out.push({ ...w });
  }
  return out;
}

/* ---------- 逐行修正 ---------- */
const rebuilt = [];

for (const line of raw.lines || []) {
  if (line.end <= T_START || line.start >= T_END) continue;

  // 1) 合并英文碎片
  const merged = mergeFragments(line.words || []);

  // 2) 专有名词替换（替换后整块保留为一个高亮单元）
  const fixed = merged.map((w) => {
    const raw = String(w.t || "").trim();
    const right = fixTerm(raw);
    if (right) return { ...w, t: right, term: true };
    return { ...w, t: raw };
  });

  // 3) 列举分隔 + 中英混排留白
  for (let i = 0; i < fixed.length; i++) {
    const w = fixed[i];
    const nxt = fixed[i + 1];
    const core = stripPunct(w.t);
    if (!core) continue;

    // AI / GPT 这类英文缩写和中文的间隔交给第 4 步统一处理（这里再加会出现双空格、行首空格）
    if (/^(AI|GPT)$/i.test(core)) continue;
    // 专有名词后面如果是下一项列举（停顿明显或也是专有名词），补顿号
    if (w.term && nxt) {
      const gap = nxt.s - w.e;
      const nextIsTerm = !!nxt.term;
      const endsWithPunct = /[，。、；：,.;:！？!?]$/.test(w.t);
      if (!endsWithPunct && (nextIsTerm || gap >= 0.2)) w.t = w.t + "、";
    }
  }

  // 4) 中文 ↔ 英文边界留一个空格（否则会黏成 "的DeepSeek"、"呢WorkBuddy"）
  const isCJK = (ch) => /[\u4e00-\u9fa5]/.test(ch || "");
  const isEN = (ch) => /[A-Za-z]/.test(ch || "");
  for (let i = 1; i < fixed.length; i++) {
    const prevLast = (fixed[i - 1].t || "").trim().slice(-1);
    const curFirst = (fixed[i].t || "").trim()[0];
    if (!prevLast || !curFirst) continue;
    if ((isCJK(prevLast) && isEN(curFirst)) || (isEN(prevLast) && isCJK(curFirst))) {
      fixed[i].t = " " + fixed[i].t;
    }
  }

  // 5) 文本 = 词拼合
  let text = fixed.map((w) => w.t).join("");
  text = text.replace(/\s{2,}/g, " ").replace(/^[\s，。、；：,.;:]+/, "").replace(/[，。、；：,.;:]+$/, "").trim();
  if (!text) continue;

  const start = Math.max(T_START, Number(fixed[0]?.s ?? line.start));
  const end = Math.min(T_END, Number(fixed[fixed.length - 1]?.e ?? line.end));

  rebuilt.push({
    start: Number(start.toFixed(3)),
    end: Number(end.toFixed(3)),
    text,
    words: fixed.map((w) => ({ t: w.t, s: Number(w.s.toFixed(3)), e: Number(w.e.toFixed(3)) })),
  });
}

/* ---------- 人工校订表 ----------
 * ASR 有三类问题自动规则修不掉，只能人写：
 *   1) 中文专有名词被按字拆碎（"统/一/千万"），逐词规则匹配不上
 *   2) 一句话被切在两行（"出发的时" / "机好紧接..."），不合并读不通
 *   3) 同音错字（"凌晨本"→"零成本"、"难波万"→"Number One"）
 *
 * 表结构：
 *   at    该行原始起始时间（秒，用来定位，唯一）
 *   span  覆盖几行（默认 1；2 = 把下一行一起吃进来）
 *   text  人工写好的正确文案（标点齐全，可直接读）
 *
 * 未列出的行保持自动结果。改文案只改这张表，不动代码。
 */
const OVERRIDE_FILE = getArg("--override", "pipeline/course-override.json");
const OVERRIDE = fs.existsSync(OVERRIDE_FILE) ? JSON.parse(fs.readFileSync(OVERRIDE_FILE, "utf8")) : [];

/** 把一句文案切成词块，并按字数比例分配时长（用于重写行） */
function splitWords(text, start, end) {
  const chunks = [];
  const tailPunct = /[，。、；：！？,.;:!?]+$/;
  const isCJK = (c) => /[\u4e00-\u9fa5]/.test(c || "");
  const isEN = (c) => /[A-Za-z0-9]/.test(c || "");

  // 中英文交界补空格，否则字幕会黏成「WorkBuddy和Codex」
  const addChunk = (c) => {
    const prev = (chunks[chunks.length - 1] || "").replace(tailPunct, "");
    const a = prev.slice(-1);
    const b = c.slice(0, 1);
    const need = a && b && ((isEN(a) && isCJK(b)) || (isCJK(a) && isEN(b)) || (isEN(a) && isEN(b)));
    chunks.push((need ? " " : "") + c);
  };

  const parts = String(text).split(/(?<=[，。、；：！？,.;:!?])/).filter((x) => x.trim());
  for (const p of parts) {
    const core = p.replace(/[，。、；：！？,.;:!?]/g, "").trim();
    if (!core) continue;
    for (const tk of core.split(/\s+/).filter(Boolean)) {
      // 英文名/数字整体不切，中文按 2–3 字一节
      if (/^[A-Za-z0-9][A-Za-z0-9.·%+\-]*$/.test(tk)) addChunk(tk);
      else for (let i = 0; i < tk.length; i += 3) addChunk(tk.slice(i, i + 3));
    }
    const tail = p.match(tailPunct);
    if (tail && chunks.length) chunks[chunks.length - 1] += tail[0];
  }
  if (!chunks.length) return [{ t: String(text), s: start, e: end }];

  const w = (c) => c.replace(/\s/g, "").length;
  const total = chunks.reduce((a, c) => a + w(c), 0) || 1;
  const span = end - start;
  let t = start;
  return chunks.map((c) => {
    const s = t;
    t = Math.min(end, t + (w(c) / total) * span);
    return { t: c, s: Number(s.toFixed(3)), e: Number(t.toFixed(3)) };
  });
}

let overridden = 0;
const missed = [];
for (const o of OVERRIDE) {
  const i = rebuilt.findIndex((c) => Math.abs(c.start - Number(o.at)) < 0.03);
  if (i < 0) {
    missed.push(o.at);
    continue;
  }
  const cover = Math.max(1, Number(o.span || 1));
  const end = cover > 1 ? rebuilt[Math.min(rebuilt.length - 1, i + cover - 1)].end : rebuilt[i].end;
  const start = rebuilt[i].start;
  rebuilt[i].start = start;
  rebuilt[i].end = end;
  rebuilt[i].text = o.text;
  rebuilt[i].words = splitWords(o.text, start, end);
  if (cover > 1) rebuilt.splice(i + 1, cover - 1);
  overridden++;
}

if (missed.length) console.warn(`⚠ 校订表有 ${missed.length} 条没匹配到时间锚点：${missed.join(", ")}`);

/* ---------- 输出 ---------- */
const SCENES_FILE = getArg("--scenes", "");
const scenes = SCENES_FILE && fs.existsSync(SCENES_FILE) ? JSON.parse(fs.readFileSync(SCENES_FILE, "utf8")) : [];

const cfg = {
  outDir: getArg("--out-dir", "course"),
  width: 1920,
  height: 1080,
  duration: Number(T_END.toFixed(3)),
  audio: getArg("--audio", "assets/voice.m4a"),
  title: TITLE,
  brand: BRAND,
  chapter: getArg("--chapter", "01 / 图解课堂"),
  ipName: getArg("--ip-name", "米亚老师"),
  ...(getArg("--pip", "") ? { pip: { src: getArg("--pip", ""), size: Number(getArg("--pip-size", 220)) } } : {}),
  captions: rebuilt,
  ...(getArg("--base", "") === "false" ? { base: false } : {}),
  ...(scenes.length ? { scenes } : {}),
};

// 只在输出路径带目录时才建目录；否则 "config.json" 会被当成目录建出来，写文件直接 EISDIR
const cfgDir = OUT.includes("/") ? OUT.replace(/\/[^/]+$/, "") : "";
if (cfgDir && cfgDir !== ".") fs.mkdirSync(cfgDir, { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(cfg, null, 2));

console.log(`✔ 输出 ${OUT}`);
console.log(`  区间 ${T_START}–${T_END}s ｜ 字幕 ${rebuilt.length} 行 ｜ 词 ${rebuilt.reduce((a, c) => a + c.words.length, 0)} 个`);
rebuilt.forEach((c, i) =>
  console.log(`  [${String(i + 1).padStart(2)}] ${c.start.toFixed(2)}→${c.end.toFixed(2)}  ${c.text}`)
);
