#!/usr/bin/env python3
"""
align-script.py — 没有转写模型时的替代：用户给「文字稿」，按语音停顿把每句话对上时间。

原理：
  1. ffmpeg silencedetect 找停顿 → 得到 N 段连续语音；
  2. 文字稿按标点切成分句，按「音节」计重（汉字 1，英文词按长度 1–3，标点 0）；
  3. 按语速把分句依次装进语音段（动态规划，让每段的音节数与时长最匹配）；
  4. 段内按音节比例分配到逐词时间戳。
输出格式与 transcribe.py + t2s.py 的产物一致，可以直接喂给 mkoverride / course-fix，
文字就是用户原稿，所以不需要再写校订稿（override 给空数组即可）。

用法：
  python3 align-script.py <音频或视频> <文字稿.txt> --out transcript-cn.json
  python3 align-script.py voice.m4a script.txt --out t.json --noise -32 --min-pause 0.25
"""
import argparse
import json
import re
import subprocess

SENT_END = "。！？!?；;"


def speech_segments(path, noise, min_pause):
    err = subprocess.run(
        ["ffmpeg", "-v", "info", "-i", path, "-af", f"silencedetect=noise={noise}dB:d={min_pause}", "-f", "null", "-"],
        capture_output=True, text=True).stderr
    dur = float(subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path]).decode().strip())
    ev = re.findall(r"silence_(start|end): ([0-9.]+)", err)
    segs, cur = [], 0.0
    for k, t in ev:
        t = float(t)
        if k == "start":
            if t - cur > 0.05:
                segs.append((cur, t))
        else:
            cur = t
    if dur - cur > 0.2:
        segs.append((cur, dur))
    return segs, dur


def tokens(s):
    out = []
    for m in re.finditer(r"[A-Za-z0-9]+|\S| ", s):
        t = m.group()
        if t == " " or re.fullmatch(r"[，。、；：！？,.;:!?“”‘’「」（）()…—\-\"']", t):
            out.append((t, 0))
        elif re.fullmatch(r"[A-Za-z0-9]+", t):
            out.append((t, 1 if len(t) <= 2 and t.isdigit() else max(1, min(3, round(len(t) / 3)))))
        else:
            out.append((t, 1))
    return out


def clauses(text):
    text = re.sub(r"\s*\n\s*", "", text.strip())
    parts = re.findall(r"[^，。、；：！？,;:!?]*[，。、；：！？,;:!?]?", text)
    out = []
    for p in parts:
        p = p.strip()
        if not p:
            continue
        # 「、」不单独成句，并到同一分句里
        if out and (out[-1].endswith("、") or not re.search(r"[，。；：！？,;:!?]$", out[-1])):
            out[-1] += p
        else:
            out.append(p)
    return [c for c in out if c]


def assign(cl_w, segs):
    """动态规划：把 M 个分句按顺序切成 N 组，对应 N 段语音；代价 = 每组(音节/时长 - 语速)^2 * 时长"""
    M, N = len(cl_w), len(segs)
    tot = sum(cl_w)
    rate = tot / sum(b - a for a, b in segs)
    pre = [0]
    for w in cl_w:
        pre.append(pre[-1] + w)
    INF = float("inf")
    # 允许一段语音没有分句（咳嗽/气口）：组可以为空，但代价加罚
    dp = [[INF] * (M + 1) for _ in range(N + 1)]
    bk = [[0] * (M + 1) for _ in range(N + 1)]
    dp[0][0] = 0
    for j in range(1, N + 1):
        d = segs[j - 1][1] - segs[j - 1][0]
        for i in range(0, M + 1):
            for k in range(0, i + 1):
                if dp[j - 1][k] == INF:
                    continue
                w = pre[i] - pre[k]
                c = (w - rate * d) ** 2 / max(d, 0.3) + (4 if w == 0 else 0)
                if dp[j - 1][k] + c < dp[j][i]:
                    dp[j][i], bk[j][i] = dp[j - 1][k] + c, k
    groups, i = [], M
    for j in range(N, 0, -1):
        k = bk[j][i]
        groups.append(list(range(k, i)))
        i = k
    return groups[::-1], rate


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("media")
    ap.add_argument("script")
    ap.add_argument("--out", required=True)
    ap.add_argument("--noise", type=float, default=-32)
    ap.add_argument("--min-pause", type=float, default=0.25)
    a = ap.parse_args()

    segs, dur = speech_segments(a.media, a.noise, a.min_pause)
    cls = clauses(open(a.script, encoding="utf8").read())
    tks = [tokens(c) for c in cls]
    cw = [sum(w for _, w in t) for t in tks]
    groups, rate = assign(cw, segs)

    caps = []
    for (sa, sb), g in zip(segs, groups):
        if not g:
            continue
        gap = 0.12 if len(g) > 1 else 0
        span = (sb - sa) - gap * (len(g) - 1)
        tot = sum(cw[i] for i in g) or 1
        t = sa
        for i in g:
            dur_c = span * cw[i] / tot
            words, x, pending = [], t, ""
            for tok, w in tks[i]:
                d = dur_c * w / cw[i] if cw[i] else 0
                if w == 0 and tok in "“‘「（(":
                    pending += tok
                    continue
                if w == 0 and words:
                    words[-1]["t"] += tok
                    continue
                if w == 0:
                    pending += tok
                    continue
                words.append({"t": pending + tok, "s": round(x, 3), "e": round(x + d, 3)})
                x += d
                pending = ""
            caps.append({"start": round(t, 3), "end": round(t + dur_c, 3),
                         "text": "".join(w["t"] for w in words), "words": words})
            t += dur_c + gap

    # 与 transcribe.py 产物同一结构（course-fix 读 lines）
    payload = {"source": a.media.split("/")[-1], "model": "script-align", "language": "zh",
               "duration": round(dur, 3), "lines": caps, "full_text": "".join(c["text"] for c in caps)}
    json.dump(payload, open(a.out, "w", encoding="utf8"), ensure_ascii=False, indent=1)
    print(f"✔ {a.out}  {len(caps)} 句 / {len(segs)} 段语音 / 语速 {rate:.1f} 音节每秒 / 时长 {dur:.2f}s")
    for c in caps:
        print(f"  {c['start']:6.2f}–{c['end']:6.2f}  {c['text']}")
    print("  对不上时：调 --noise（嘈杂 -28，安静 -36）或 --min-pause（0.2–0.4）再跑")


if __name__ == "__main__":
    main()
