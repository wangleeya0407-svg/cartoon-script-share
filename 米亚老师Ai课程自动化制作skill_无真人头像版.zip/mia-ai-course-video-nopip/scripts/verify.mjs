#!/usr/bin/env node
/**
 * verify.mjs — 渲染后的"自验收"
 *
 * 作用：用 ffprobe 检查 MP4 的时长 / 帧率 / 音轨，和我们时间轴里的预期对比。
 * 这是流水线的最后一道闸门：退出码 0 不等于成片合格，必须实测。
 *
 * 用法：
 *   node pipeline/verify.mjs out.mp4
 *   node pipeline/verify.mjs out.mp4 --timeline pipeline/example.timeline.json
 *   node pipeline/verify.mjs out.mp4 --expect-audio        # 要求必须有音轨
 */

import fs from "node:fs";
import { execFileSync } from "node:child_process";
import process from "node:process";

const args = process.argv.slice(2);
const file = args.find((a) => !a.startsWith("--"));
if (!file) {
  console.error("用法：node pipeline/verify.mjs <mp4> [--timeline <json>] [--expect-audio]");
  process.exit(2);
}
if (!fs.existsSync(file)) {
  console.error(`✖ 找不到输出文件：${file}`);
  process.exit(2);
}
const stat = fs.statSync(file);
if (stat.size === 0) {
  console.error("✖ 输出文件是空的（0 字节），渲染失败。");
  process.exit(2);
}

const tlIdx = args.indexOf("--timeline");
const timelinePath =
  tlIdx >= 0 && args[tlIdx + 1] ? args[tlIdx + 1] : "pipeline/example.timeline.json";
const expectAudio = args.includes("--expect-audio");
const edIdx = args.indexOf("--expect-duration");
const expectDuration =
  edIdx >= 0 && args[edIdx + 1] && Number.isFinite(Number(args[edIdx + 1]))
    ? Number(args[edIdx + 1])
    : null;

// ffprobe 输出 JSON
let probe;
try {
  const out = execFileSync(
    "ffprobe",
    ["-v", "error", "-show_format", "-show_streams", "-of", "json", file],
    { encoding: "utf8" }
  );
  probe = JSON.parse(out);
} catch (e) {
  console.error("✖ ffprobe 调用失败（是否安装了 FFmpeg？）：", e.message);
  process.exit(2);
}

const streams = probe.streams || [];
const v = streams.find((s) => s.codec_type === "video");
const a = streams.find((s) => s.codec_type === "audio");
const duration = Number(probe.format?.duration || v?.duration || 0);

let fps = null;
if (v?.avg_frame_rate && v.avg_frame_rate !== "0/0") {
  const [n, d] = v.avg_frame_rate.split("/").map(Number);
  if (d) fps = n / d;
}

// 读预期时长（--expect-duration 优先，否则读时间轴）
let expected = expectDuration;
if (expected == null) {
  try {
    const spec = JSON.parse(fs.readFileSync(timelinePath, "utf8"));
    const scenes = spec.scenes || [];
    let t = scenes.length
      ? Math.max(...scenes.map((s) => Number(s.start) + Number(s.duration || 3)))
      : 0;
    for (const au of spec.audio || []) {
      if (au.duration != null) t = Math.max(t, Number(au.start) + Number(au.duration));
    }
    expected = t;
  } catch {
    /* 时间轴读不到就只做基础检查 */
  }
}

const results = [];
const ok = (label, pass, detail) => results.push({ label, pass, detail });

ok("文件非空", stat.size > 0, `${(stat.size / 1024 / 1024).toFixed(2)} MB`);
ok("有视频流", !!v, v ? `${v.codec_name} ${v.width}x${v.height}` : "无视频流");
ok("时长 > 0", duration > 0, `${duration.toFixed(2)}s`);
ok("分辨率匹配画幅", !!v, v ? `${v.width}x${v.height}` : "-");

if (expected != null) {
  const diff = Math.abs(duration - expected);
  const tol = Math.max(0.5, expected * 0.02);
  ok(
    "时长与时间轴一致",
    diff <= tol,
    `实际 ${duration.toFixed(2)}s / 预期 ${expected.toFixed(2)}s（容差 ${tol.toFixed(2)}s）`
  );
}

if (fps != null) ok("帧率", fps > 10, `${fps.toFixed(2)} fps`);
ok("音轨", expectAudio ? !!a : true, a ? "有" : "无（未要求）");

if (expectAudio && !a) {
  results.push({ label: "音轨必需", pass: false, detail: "要求配音但输出没有音轨" });
}

let failed = 0;
for (const r of results) {
  if (!r.pass) failed++;
  console.log(`${r.pass ? "✔" : "✖"} ${r.label}：${r.detail}`);
}

console.log(
  `\n${failed === 0 ? "✅ 验收通过" : `❌ 验收未通过（${failed} 项）`}  ${file}`
);
console.log("注意：机器验收只查时长/帧率/音轨；字幕位置、镜头观感仍需人眼通看一遍。");
process.exit(failed === 0 ? 0 : 1);
