#!/usr/bin/env node
/**
 * mkoverride.mjs — 把「按行号写的校订稿」转成「按时间锚写的校订表」
 *
 * 为什么要有这一步：
 *   course-override.json 用 `at`（该行真实起始秒数）做锚点，但人手抄 100 多行带两位小数的
 *   时间戳几乎一定会错，错一个就丢一条校订、字幕还是错字。而转写里每行的 start 是权威值。
 *   所以校订稿只写行号（i），这里按转写自动换算成 `at`，一次都不会错。
 *
 * 用法：
 *   node pipeline/mkoverride.mjs talk/video-basics.json pipeline/override-src/video-basics.json \
 *        --out pipeline/course-override-video-basics.json
 *
 * 校订稿格式：[{ i: 行号, span: 覆盖几行(默认1), text: 正确文案 }]
 */
import fs from "node:fs";
import process from "node:process";

const argv = process.argv.slice(2);
const srcTranscript = argv[0];
const srcOverride = argv[1];
const iOut = argv.indexOf("--out");
const OUT = iOut >= 0 ? argv[iOut + 1] : "pipeline/course-override.json";

if (!srcTranscript || !srcOverride) {
  console.error("用法: node pipeline/mkoverride.mjs <转写json> <校订稿json> --out <校订表json>");
  process.exit(1);
}

const t = JSON.parse(fs.readFileSync(srcTranscript, "utf8"));
const entries = JSON.parse(fs.readFileSync(srcOverride, "utf8"));
const lines = t.lines || [];

const out = [];
const used = new Set();
let lastEnd = -1;
const problems = [];

for (const e of entries) {
  const i = Number(e.i);
  const line = lines[i];
  if (!line) {
    problems.push(`行号 ${i} 超出范围（共 ${lines.length} 行）`);
    continue;
  }
  const span = Math.max(1, Number(e.span || 1));
  // 覆盖区间不能和上一条重叠，否则后一条会吃掉前一条已经并掉的行
  for (let k = 0; k < span; k++) {
    if (used.has(i + k)) problems.push(`行 ${i + k} 被两条校订重复覆盖`);
    used.add(i + k);
  }
  if (line.start < lastEnd - 0.001) problems.push(`行 ${i}（${line.start}s）和上一条时间重叠`);
  lastEnd = lines[Math.min(lines.length - 1, i + span - 1)].end;
  if (!String(e.text || "").trim()) problems.push(`行 ${i} 文案为空`);

  out.push({ at: Number(line.start.toFixed(3)), span, text: e.text });
}

// 没被任何校订覆盖的行，说明漏写了，字幕会保留 ASR 原文
const missing = lines.map((_, i) => i).filter((i) => !used.has(i));

// 只在输出路径带目录时才建目录；否则 "xxx.json" 会被当成目录建出来，写文件直接 EISDIR
const outDir = OUT.includes("/") ? OUT.replace(/\/[^/]+$/, "") : "";
if (outDir && outDir !== ".") fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(OUT, JSON.stringify(out, null, 2));

console.log(`✔ ${OUT}`);
console.log(`  校订 ${out.length} 条 ｜ 覆盖 ${used.size}/${lines.length} 行`);
if (missing.length) console.log(`  ⚠ 未校订的行：${missing.join(", ")}`);
if (problems.length) {
  console.log("  ✖ 有问题：");
  problems.forEach((p) => console.log("    - " + p));
  process.exitCode = 1;
}
