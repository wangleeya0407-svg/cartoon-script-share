#!/bin/bash
# 渲染成片 + 压缩 + 参数自检
#
# 用法：bash render.sh <课程slug> [成片文件名]
#   例：bash render.sh api-course "API入门课_成片.mp4"
#
# 关键：必须用 HF_SEGMENTED_CAPTURE=true + -w 2。
#       4 worker 渲染长片会在 70% 附近掉临时帧，2 worker 分段捕获 0 重试。
set -e

SLUG="${1:?用法: bash render.sh <课程slug> [成片文件名]}"
NAME="${2:-${SLUG}_成片.mp4}"

if [ ! -f "$SLUG/index.html" ]; then
  echo "✗ 找不到 $SLUG/index.html，先跑 $SLUG/run.sh"
  exit 1
fi

echo "▶ 渲染整片（分段捕获 / 2 worker）"
HF_SEGMENTED_CAPTURE=true npx hyperframes render "$SLUG" --quality looks -w 2 \
  --output "$SLUG/out.mp4"

echo "▶ 压缩（CRF 21，约省 45%）"
ffmpeg -v error -i "$SLUG/out.mp4" \
  -c:v libx264 -crf 21 -preset medium -pix_fmt yuv420p \
  -c:a aac -b:a 128k -movflags +faststart \
  -y "$SLUG/$NAME"

echo
echo "▶ 参数自检"
for f in "$SLUG/out.mp4" "$SLUG/$NAME"; do
  D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$f")
  S=$(du -h "$f" | cut -f1)
  R=$(ffprobe -v error -select_streams v:0 -show_entries stream=width,height,r_frame_rate,nb_frames -of csv=p=0 "$f")
  A=$(ffprobe -v error -select_streams a -show_entries stream=codec_name -of csv=p=0 "$f")
  printf "  %-46s %8ss %6s  %s  音频:%s\n" "$f" "${D%.*}" "$S" "$R" "${A:-无}"
done

echo
echo "✔ 成片：$SLUG/$NAME"
echo "  还要做抽帧验收：bash verify.sh $SLUG $SLUG/$NAME"
