#!/usr/bin/env node
/**
 * build-course.mjs — 「语音 → 知识动画片」生成器（横屏 1920×1080）
 *
 * 和 wrap-talk（口播套字幕）不同：这里不用任何拍摄画面，
 * 全部画面由 CSS + SVG + GSAP 现场画出来，语音只提供「说什么、什么时候说」。
 *
 * 分镜（由转写时间戳驱动，改 config 里的时间画面自动跟着变）：
 *   S1  0.00– 5.64  封面
 *   S2  5.64–12.60  三者是什么关系（三张卡片 + 连线）
 *   S3 12.60–26.70  大模型 = 发动机（转轮 + 品牌标签依次点亮）
 *   S4 26.70–40.12  AI 工具 = 汽车（车身描边 + 工具标签 + "只是工具"）
 *   S5 40.12–43.66  你和我 = 司机
 *   S6 43.66–52.70  三者总图 + 收尾
 *
 * 用法：node pipeline/build-course.mjs course/config.json
 */

import fs from "node:fs";
import path from "node:path";
import process from "node:process";

const cfgPath = process.argv[2] || "course/config.json";
const cfg = JSON.parse(fs.readFileSync(cfgPath, "utf8"));

const OUT = cfg.outDir || "course";
const W = Number(cfg.width || 1920);
const H = Number(cfg.height || 1080);
const DURATION = Number(cfg.duration);
const AUDIO = cfg.audio || "assets/voice.m4a";

/* 是否使用第一课那 6 个手写场景（封面/三卡/发动机/汽车/司机/总图）。
 * 讲别的主题时 config 里写 base: false，全部场景走 scenes 数据，手写代码不参与。 */
const BASE = cfg.base !== false;

const esc = (s = "") =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
const f3 = (v) => Number(v).toFixed(3);

if (!DURATION) {
  console.error("✖ config 里缺 duration");
  process.exit(1);
}

/* ══════════════ 分镜边界（跟语音时间对齐） ══════════════ */
const B = {
  s1: 0,
  s2: 5.64,
  s3: 12.6,
  s4: 26.7,
  s5: 40.12,
  s6: 43.66,
  s7: 52.7, // 第一章（三者关系）收尾，之后交给数据驱动的第二章起
  end: DURATION,
};

/* ══════════════ 字幕 ══════════════ */
const rawCaptions = (cfg.captions || []).filter((c) => Number.isFinite(Number(c.start)));

/**
 * 合并过短的字幕行：
 *   口播语速常常一句话不到 1.5 秒，单独成行观众读不完。
 *   条件：本行不足 1.4 秒 + 与下一行间隔不足 0.4 秒 + 合并后不超过 22 字 + 本行不以句末标点结尾。
 *   合并后高亮时间仍用原来的逐词时间戳，所以和语音不会脱节。
 */
const SCENE_STARTS = (cfg.scenes || []).map((x) => Number(x.start)).filter((x) => x > 0);
function mergeShortCaptions(list) {
  const visW = (s) => {
    let n = 0;
    for (const ch of String(s).replace(/\s/g, "")) n += /[\x00-\x7F]/.test(ch) ? 0.6 : 1;
    return n;
  };
  const out = [];
  for (let i = 0; i < list.length; i++) {
    const cur = { ...list[i], words: [...(list[i].words || [])] };
    while (i + 1 < list.length) {
      const nxt = list[i + 1];
      const dur = Number(cur.end) - Number(cur.start);
      const gap = Number(nxt.start) - Number(cur.end);
      const joined = String(cur.text) + String(nxt.text);
      if (dur >= 1.4 || gap > 0.4 || visW(joined) > 22) break;
      /* 句末（。；！？）不往后并：下一句往往属于下一个画面，并过去会让字幕提前剧透 */
      /* course-fix 会去掉 text 末尾标点，所以看最后一个词（标点留在词上） */
      const lastWord = (cur.words && cur.words.length ? cur.words[cur.words.length - 1].t : cur.text) || "";
      if (/[。；;！!？?]\s*$/.test(String(lastWord)) || /[。；;！!？?]$/.test(String(cur.text).trim())) break;
      /* 中间隔着换场景就不并：字幕要和画面同进同出 */
      if (SCENE_STARTS.some((b) => b > Number(cur.end) - 0.05 && b < Number(nxt.start) + 0.3)) break;
      const needsComma = !/[，。、；：,.;:！？!?]$/.test(String(cur.text));
      cur.text = String(cur.text) + (needsComma ? "，" : "") + String(nxt.text);
      cur.end = Number(nxt.end);
      cur.words = [...(cur.words || []), ...(nxt.words || [])];
      i += 1;
    }
    out.push(cur);
  }
  return out;
}

/**
 * 拆过长的字幕行：
 *   一行超过 24 个「视觉字」或 6.2 秒，手机上会挤成一堵墙，读不完。
 *   视觉字：中文算 1，ASCII（英文/数字）算 1.9 —— WorkBuddy 一个词顶 9 个汉字宽，
 *   只按去空格字数算会导致中英混排行实际超宽、被折成两行甚至挤出框。
 *   断开顺序：先按标点切语义段 → 装箱到 MAXC → 尾巴 <6 视觉字并回前屏（不留碎片）。
 */
function splitLongCaptions(list, MAXC = 24, MAXD = 6.2) {
  const vis = (s) => {
    let n = 0;
    for (const ch of String(s).replace(/\s/g, "")) n += /[\x00-\x7F]/.test(ch) ? 0.6 : 1;
    return n;
  };
  const out = [];
  for (const c of list) {
    const words = Array.isArray(c.words) ? c.words : [];
    if (!words.length) { out.push(c); continue; }
    const total = words.reduce((a, w) => a + vis(w.t), 0);
    if (total <= MAXC && c.end - c.start <= MAXD) { out.push(c); continue; }

    // ① 按标点切成语义段，绝不在词中间断
    const segs = [];
    let ws = [], wl = 0;
    for (const w of words) {
      ws.push(w);
      wl += vis(w.t);
      if (/[，。、；：！？]$/.test(String(w.t).trim())) {
        segs.push({ words: ws, len: wl });
        ws = []; wl = 0;
      }
    }
    if (ws.length) segs.push({ words: ws, len: wl });

    // ② 装箱到不超过 MAXC 的屏；单段本身超宽时在段内按词硬拆
    const groups = [];
    let g = [], gl = 0;
    const flush = () => { if (g.length) { groups.push({ words: g, len: gl }); g = []; gl = 0; } };
    for (const s of segs) {
      if (s.len > MAXC) {
        flush();
        let part = [], pl = 0;
        for (const w of s.words) {
          const ww = vis(w.t);
          if (part.length && pl + ww > MAXC) { groups.push({ words: part, len: pl }); part = []; pl = 0; }
          part.push(w); pl += ww;
        }
        if (part.length) groups.push({ words: part, len: pl });
        continue;
      }
      if (g.length && gl + s.len > MAXC) flush();
      g.push(...s.words); gl += s.len;
    }
    flush();

    // ③ 尾巴太短就并回前一屏：宁可行两行，也不留「要多。」这种碎片
    if (groups.length > 1 && groups[groups.length - 1].len < 6) {
      const last = groups.pop();
      const prev = groups[groups.length - 1];
      prev.words = prev.words.concat(last.words);
      prev.len += last.len;
    }
    if (groups.length <= 1) { out.push(c); continue; }

    // ④ 每屏起止取该屏首词/末词的真实时间，逐词高亮仍然准
    for (const gr of groups) {
      const f = gr.words[0];
      const l = gr.words[gr.words.length - 1];
      out.push({
        start: Number(f.s),
        end: Number(l.e) || c.end,
        text: gr.words.map((w) => w.t).join("").trim(),
        words: gr.words,
      });
    }
  }
  return out;
}

const captions = splitLongCaptions(mergeShortCaptions(rawCaptions));

let wordTotal = 0;
const captionHtml = captions
  .map((c, i) => {
    const words = Array.isArray(c.words) && c.words.length ? c.words : [{ t: c.text, s: c.start, e: c.end }];
    wordTotal += words.length;
    const inner = words
      .map((w, j) => `<span class="w" id="w-${i}-${j}">${esc(w.t)}</span>`)
      .join("");
    return `      <div class="caption clip" id="cap-${i}" data-start="${f3(c.start)}" data-duration="${f3(
      Number(c.end) - Number(c.start)
    )}" data-track-index="6"><span class="caption-inner">${inner}</span></div>`;
  })
  .join("\n");

/* ══════════════ 通用小图标（纯 SVG） ══════════════ */
const ICON_ENGINE = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <circle cx="60" cy="60" r="40" fill="none" stroke="currentColor" stroke-width="6" stroke-dasharray="7 9"/>
  <g stroke="currentColor" stroke-width="7" stroke-linecap="round">
    <line x1="60" y1="26" x2="60" y2="42"/><line x1="60" y1="78" x2="60" y2="94"/>
    <line x1="26" y1="60" x2="42" y2="60"/><line x1="78" y1="60" x2="94" y2="60"/>
    <line x1="36" y1="36" x2="48" y2="48"/><line x1="72" y1="72" x2="84" y2="84"/>
    <line x1="84" y1="36" x2="72" y2="48"/><line x1="48" y1="72" x2="36" y2="84"/>
  </g>
  <circle cx="60" cy="60" r="13" fill="currentColor"/>
</svg>`;

const ICON_CAR = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <path d="M14 76 L20 56 Q24 46 36 44 L74 40 Q86 39 92 48 L102 64 L104 76"
        fill="none" stroke="currentColor" stroke-width="7" stroke-linejoin="round" stroke-linecap="round"/>
  <path d="M38 46 L44 30 L72 28 L80 44" fill="none" stroke="currentColor" stroke-width="6" stroke-linejoin="round"/>
  <circle cx="34" cy="82" r="12" fill="none" stroke="currentColor" stroke-width="7"/>
  <circle cx="86" cy="82" r="12" fill="none" stroke="currentColor" stroke-width="7"/>
</svg>`;

const ICON_HUMAN = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <circle cx="60" cy="36" r="17" fill="none" stroke="currentColor" stroke-width="7"/>
  <path d="M28 100 Q30 66 60 64 Q90 66 92 100" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
</svg>`;

/* ══════════════ 主画面（发动机 / 车身 / 方向盘） ══════════════ */
const ENGINE_ART = `
<div class="art" id="engineArt">
  <div class="art-halo" id="engineHalo"></div>
  <div class="eng-stage">
    <div class="eng-ring eng-ring-1" id="engRing1"></div>
    <div class="eng-ring eng-ring-2" id="engRing2"></div>
    <div class="eng-blades" id="engBlades">
      <i style="--a:0deg"></i><i style="--a:45deg"></i><i style="--a:90deg"></i><i style="--a:135deg"></i>
      <i style="--a:180deg"></i><i style="--a:225deg"></i><i style="--a:270deg"></i><i style="--a:315deg"></i>
    </div>
    <div class="eng-hub"><div class="eng-core" id="engCore"></div></div>
  </div>
</div>`;


const CAR_ART = `
<div class="art" id="carArt">
  <div class="art-halo" id="carHalo"></div>
  <svg viewBox="0 0 520 300" class="art-svg">
    <path id="carBody"
      d="M40 200 L58 140 Q70 106 112 100 L330 84 Q392 80 418 120 L470 190 L474 200"
      fill="none" stroke="#0FB5A0" stroke-width="9" stroke-linejoin="round" stroke-linecap="round"/>
    <path id="carRoof"
      d="M132 100 L156 44 L300 32 L344 88"
      fill="none" stroke="#0FB5A0" stroke-width="8" stroke-linejoin="round" stroke-linecap="round"/>
    <path id="carGlass" d="M168 92 L186 56 L286 48 L320 88" fill="rgba(15,181,160,0.14)" stroke="none"/>
    <line id="carBase" x1="40" y1="204" x2="474" y2="204" stroke="rgba(15,181,160,0.55)" stroke-width="4" stroke-linecap="round"/>
    <g id="carWheels">
      <circle cx="128" cy="206" r="40" fill="#FFFFFF" stroke="#0FB5A0" stroke-width="9"/>
      <circle cx="128" cy="206" r="14" fill="#0FB5A0"/>
      <circle cx="392" cy="206" r="40" fill="#FFFFFF" stroke="#0FB5A0" stroke-width="9"/>
      <circle cx="392" cy="206" r="14" fill="#0FB5A0"/>
    </g>
  </svg>
  <div class="engine-slot" id="engineSlot"><span>发动机</span></div>
</div>`;

const WHEEL_ART = `
<div class="art" id="wheelArt">
  <div class="art-halo" id="wheelHalo"></div>
  <svg viewBox="0 0 400 400" class="art-svg">
    <circle cx="200" cy="200" r="150" fill="none" stroke="#F59E0B" stroke-width="16" opacity="0.9"/>
    <circle cx="200" cy="200" r="150" fill="none" stroke="rgba(245,158,11,0.28)" stroke-width="44"/>
    <line x1="200" y1="86" x2="200" y2="152" stroke="#F59E0B" stroke-width="14" stroke-linecap="round"/>
    <line x1="200" y1="248" x2="200" y2="314" stroke="#F59E0B" stroke-width="14" stroke-linecap="round"/>
    <line x1="86" y1="200" x2="152" y2="200" stroke="#F59E0B" stroke-width="14" stroke-linecap="round"/>
    <line x1="248" y1="200" x2="314" y2="200" stroke="#F59E0B" stroke-width="14" stroke-linecap="round"/>
    <circle cx="200" cy="200" r="46" fill="#FFFFFF" stroke="#F59E0B" stroke-width="10"/>
    <circle cx="200" cy="200" r="14" fill="#F59E0B"/>
  </svg>
</div>`;

/* ══════════════ 场景 HTML ══════════════ */
const sceneWrap = (id, start, dur, inner, extra = "") =>
  `      <div class="scene clip ${extra}" id="${id}" data-start="${f3(start)}" data-duration="${f3(
    dur
  )}" data-track-index="1">
${inner}
      </div>`;

/* --- S1 封面 --- */
const S1 = sceneWrap(
  "s1",
  B.s1,
  B.s2 - B.s1,
  `        <div class="s1-wrap">
          <div class="chip" id="s1-chip"><span class="dot"></span>新手入门课</div>
          <h1 class="s1-title" id="s1-title">大模型<span class="sep">·</span>工具<span class="sep">·</span>你</h1>
          <div class="s1-rule" id="s1-rule"></div>
          <p class="s1-sub" id="s1-sub">从 0 到 1，先把三者关系讲清楚</p>
          <div class="s1-icons" id="s1-icons">
            <div class="s1-icon i1">${ICON_ENGINE}<span>大模型</span></div>
            <div class="s1-icon i2">${ICON_CAR}<span>AI 工具</span></div>
            <div class="s1-icon i3">${ICON_HUMAN}<span>你</span></div>
          </div>
        </div>
        <div class="ip-hero" id="s1-ip"><img src="assets/mascot/mia-talk.png" alt="" /></div>`
);

/* --- S2 三者关系 --- */
const S2 = sceneWrap(
  "s2",
  B.s2,
  B.s3 - B.s2,
  `        <div class="s2-wrap">
          <h2 class="h2" id="s2-title">它们之间，到底是什么关系？</h2>
          <div class="s2-row">
            <div class="s2-card c-blue" id="s2-c1">
              <div class="s2-ico">${ICON_ENGINE}</div>
              <div class="s2-name">大模型</div>
              <div class="s2-note">能力来源</div>
            </div>
            <div class="s2-link" id="s2-link1"><i></i></div>
            <div class="s2-card c-teal" id="s2-c2">
              <div class="s2-ico">${ICON_CAR}</div>
              <div class="s2-name">AI 工具</div>
              <div class="s2-note">干活的载体</div>
            </div>
            <div class="s2-link" id="s2-link2"><i></i></div>
            <div class="s2-card c-amber" id="s2-c3">
              <div class="s2-ico">${ICON_HUMAN}</div>
              <div class="s2-name">你</div>
              <div class="s2-note">决定做什么</div>
            </div>
          </div>
          <div class="s2-q" id="s2-q">先讲清楚：谁在提供能力，谁在干具体的活</div>
        </div>`
);

/* --- S3 大模型 = 发动机 --- */
const S3 = sceneWrap(
  "s3",
  B.s3,
  B.s4 - B.s3,
  `        <div class="split">
          <div class="split-left">
            <div class="kicker" id="s3-kicker">01　大模型</div>
            <h2 class="split-title" id="s3-title">大模型 = 发动机</h2>
            <p class="split-desc" id="s3-desc">有本事、有动力，<br/>能力特别强</p>
            <div class="tags" id="s3-tags">
              <span class="tag t-blue" id="s3-t1">DeepSeek</span>
              <span class="tag t-blue" id="s3-t2">豆包</span>
              <span class="tag t-blue" id="s3-t3">Kimi</span>
              <span class="tag t-blue" id="s3-t4">GPT</span>
            </div>
            <div class="punch" id="s3-punch"><span>能力都特别强</span></div>
          </div>
          <div class="split-right">${ENGINE_ART}</div>
        </div>`
);

/* --- S4 AI 工具 = 汽车 --- */
const S4 = sceneWrap(
  "s4",
  B.s4,
  B.s5 - B.s4,
  `        <div class="split">
          <div class="split-left">
            <div class="kicker" id="s4-kicker">02　AI 工具</div>
            <h2 class="split-title" id="s4-title">AI 工具 = 汽车</h2>
            <p class="split-desc" id="s4-desc">把发动机装进车身<br/>车才跑得起来</p>
            <div class="tags" id="s4-tags">
              <span class="tag t-teal" id="s4-t1">WorkBuddy</span>
              <span class="tag t-teal" id="s4-t2">Codex</span>
              <span class="tag t-teal" id="s4-t3">豆包</span>
              <span class="tag t-teal" id="s4-t4">通义 / 文心</span>
            </div>
            <div class="punch punch-teal" id="s4-punch"><span>它只是工具</span></div>
          </div>
          <div class="split-right">${CAR_ART}</div>
        </div>`
);

/* --- S5 你 = 司机 --- */
const S5 = sceneWrap(
  "s5",
  B.s5,
  B.s6 - B.s5,
  `        <div class="s5-wrap">
          <div class="s5-art">${WHEEL_ART}</div>
          <div class="s5-text">
            <div class="kicker" id="s5-kicker">03　你</div>
            <h2 class="split-title" id="s5-title">你和我 = 司机</h2>
            <p class="split-desc" id="s5-desc">决定去哪、走哪条路</p>
          </div>
        </div>
        <div class="ip-hero" id="s5-ip">
          <img src="assets/mascot/mia-ok.png" alt="" />
          <div class="ip-sign" id="s5-sign">我也在这辆车上</div>
        </div>`
);

/* --- S6 总图收尾 --- */
const S6 = sceneWrap(
  "s6",
  B.s6,
  B.s7 - B.s6,
  `        <div class="s6-wrap">
          <h2 class="s6-title" id="s6-title">三者关系，一张图记住</h2>
          <div class="stack">
            <div class="layer l-blue" id="s6-l1">
              <div class="layer-ico">${ICON_ENGINE}</div>
              <div class="layer-txt"><b>大模型</b><span>发动机 · 提供能力</span></div>
            </div>
            <div class="arrow" id="s6-a1">↓</div>
            <div class="layer l-teal" id="s6-l2">
              <div class="layer-ico">${ICON_CAR}</div>
              <div class="layer-txt"><b>AI 工具</b><span>车身 · 装发动机干活</span></div>
            </div>
            <div class="arrow" id="s6-a2">↓</div>
            <div class="layer l-amber" id="s6-l3">
              <div class="layer-ico">${ICON_HUMAN}</div>
              <div class="layer-txt"><b>你</b><span>司机 · 决定方向</span></div>
            </div>
          </div>
          <div class="s6-end" id="s6-end">从 0 到 1，搞懂大模型、工具和你</div>
        </div>
        <div class="ip-hero" id="s6-ip">
          <img src="assets/mascot/mia-heart.png" alt="" />
          <div class="ip-sign" id="s6-sign">${esc(cfg.ipName || "米亚老师")} · <em>原创出品</em></div>
        </div>`
);

/* ══════════════ 第二章起用的小图标 ══════════════ */
const ICON_TEXT = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <rect x="24" y="18" width="72" height="84" rx="10" fill="none" stroke="currentColor" stroke-width="7"/>
  <line x1="38" y1="42" x2="82" y2="42" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
  <line x1="38" y1="60" x2="82" y2="60" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
  <line x1="38" y1="78" x2="64" y2="78" stroke="currentColor" stroke-width="7" stroke-linecap="round"/>
</svg>`;

const ICON_VIDEO = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <rect x="16" y="30" width="60" height="60" rx="10" fill="none" stroke="currentColor" stroke-width="7"/>
  <path d="M82 58 L104 42 L104 78 L82 62 Z" fill="none" stroke="currentColor" stroke-width="7" stroke-linejoin="round"/>
</svg>`;

const ICON_IMAGE = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <rect x="16" y="24" width="88" height="70" rx="10" fill="none" stroke="currentColor" stroke-width="7"/>
  <circle cx="41" cy="48" r="8" fill="currentColor"/>
  <path d="M24 86 L52 58 L70 76 L84 64 L96 86" fill="none" stroke="currentColor" stroke-width="7" stroke-linejoin="round"/>
</svg>`;

const ICON_VOICE = `
<svg class="ico" viewBox="0 0 120 120" aria-hidden="true">
  <line x1="24" y1="52" x2="24" y2="68" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>
  <line x1="40" y1="40" x2="40" y2="80" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>
  <line x1="56" y1="28" x2="56" y2="92" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>
  <line x1="72" y1="38" x2="72" y2="82" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>
  <line x1="88" y1="48" x2="88" y2="72" stroke="currentColor" stroke-width="8" stroke-linecap="round"/>
</svg>`;

const ICONS = { text: ICON_TEXT, video: ICON_VIDEO, image: ICON_IMAGE, voice: ICON_VOICE };

/* ══════════════ 第二章起：数据驱动场景 ══════════════
 * config.scenes 里每个对象描述一个场景，type 决定版式：
 *   chapter 章节卡 / quad 四宫格 / punch 金句 / list 要点 / vs 对比 / chain 流程 / end 结束卡
 * 每个场景自己带 start/end，和字幕时间同源，改文案改时间都不用动代码。
 */
/* ══════════════ 真人画中画（可选） ══════════════
 * cfg.pip = { "src": "assets/pip.mp4", "size": 220 }   圆形小窗
 * 素材由 scripts/make-pip.py 从口播视频裁出（无声；声音仍走 voice.m4a，口型自然同步）。
 * 位置固定右上：小窗 + 下方名牌，卡通头像贴在小窗左下角，不进入内容区（内容区从 y≈400 开始）。 */
const PIP = cfg.pip && cfg.pip.src ? {
  src: cfg.pip.src,
  size: Math.max(160, Math.min(280, Number(cfg.pip.size || 220))),
  mediaStart: Number(cfg.pip.mediaStart || 0),
} : null;
const PIP_TOP = 122, PIP_RIGHT = 48;

/* ══════════════ 米亚老师 IP 形象 ══════════════
 * 7 张：4 张半身（比心 / 指向左 / OK / 摊手讲解）+ 3 张头像（大笑 / 微笑 / 眨眼）。
 * ratio = 高 / 宽，场景大图按「高度」定尺寸，不同姿势出来一样大。
 * 旧素材名（ip-wave 等）自动映射，老分镜不用改。 */
const MASCOT = {
  "mia-heart": 1.825, "mia-point": 1.413, "mia-ok": 1.523, "mia-talk": 1.4,
  "mia-laugh": 1.479, "mia-smile": 1.465, "mia-wink": 1.444,
};
const MASCOT_ALIAS = {
  "ip-wave": "mia-talk", "ip-teach": "mia-smile", "ip-share": "mia-heart",
  "ip-work": "mia-ok", "ip-think": "mia-wink", "ip-desk": "mia-laugh",
};
const ipName = (n) => {
  const k = MASCOT_ALIAS[n] || n;
  if (!MASCOT[k]) {
    console.warn(`⚠ 未知 IP 素材「${n}」，改用 mia-talk`);
    return "mia-talk";
  }
  return k;
};
/* 半身形象默认站位：高 H_IP，left/right 交替；指向左的那张固定站右边（手指向画面中央） */
const H_IP = Number(cfg.ipHeight || 400);
const ipBox = (name, side) => {
  const w = Math.round(H_IP / MASCOT[name]);
  return `${side}:${side === "left" ? 64 : 70}px;bottom:176px;width:${w}px`;
};

/* 自动铺形象：chapter / punch / end 三种留白多的版式，没写 ip 就自动排一个。
 * 写 "ip": false 关掉这一场；config 写 "ipAuto": false 全片关掉。 */
const AUTO_TYPES = new Set(["chapter", "punch", "end"]);
const ROTATE = ["mia-point", "mia-ok", "mia-talk"];
let rot = 0;
const SCENES2 = (cfg.scenes || []).map((s0, idx, arr) => {
  const s = { ...s0 };
  if (s.ip === false || s.ip === "none") {
    delete s.ip;
    return s;
  }
  if (s.ip) {
    s.ip = ipName(s.ip);
    if (!s.ipStyle) s.ipStyle = ipBox(s.ip, s.ip === "mia-point" ? "right" : "left");
    return s;
  }
  if (cfg.ipAuto === false || !AUTO_TYPES.has(s.type)) return s;
  /* 封面、结尾站左；指向左的站右（手指画面中央）；其余左右交替 */
  let pick, side;
  if (s.type === "end" || idx === arr.length - 1) [pick, side] = ["mia-heart", "left"];
  else if (idx === 0) [pick, side] = ["mia-talk", "left"];
  else {
    pick = ROTATE[rot % ROTATE.length];
    side = pick === "mia-point" ? "right" : rot % 2 ? "left" : "right";
    rot++;
  }
  s.ip = pick;
  s.ipStyle = ipBox(pick, side);
  return s;
});

const sceneHtml = (s) => {
  const p = s.id;
  let body = "";

  if (s.type === "chapter") {
    body = `        <div class="ch">
          <div class="ch-no" id="${p}-no">${esc(s.no || "")}</div>
          <h2 class="ch-title" id="${p}-t">${esc(s.title || "")}</h2>
          ${s.sub ? `<div class="ch-sub" id="${p}-s">${esc(s.sub)}</div>` : ""}
          <div class="ch-rule" id="${p}-r"></div>
        </div>`;
  } else if (s.type === "quad") {
    body = `        <div class="quad">
          <div class="quad-head">
            ${s.kicker ? `<div class="kicker" id="${p}-k">${esc(s.kicker)}</div>` : ""}
            <h2 class="h2" id="${p}-t">${esc(s.title || "")}</h2>
          </div>
          <div class="q-grid">
${(s.items || [])
  .map(
    (it, i) => `            <div class="q-card ${esc(it.tone || "")}" id="${p}-c${i}">
              <div class="q-top">
                <div class="q-ico">${ICONS[it.icon] || ICON_TEXT}</div>
                <div>
                  <div class="q-name">${esc(it.name)}</div>
                  <div class="q-note">${esc(it.note || "")}</div>
                </div>
              </div>
              <div class="q-tags">${(it.tags || [])
                .map((t, j) => `<span id="${p}-c${i}-t${j}">${esc(t)}</span>`)
                .join("")}</div>
            </div>`
  )
  .join("\n")}
          </div>
        </div>`;
  } else if (s.type === "punch") {
    body = `        <div class="pw">
${(s.lines || [])
  .map((l, i) => `          <div class="${l.cls || "pw-line"}" id="${p}-l${i}">${l.html || esc(l.text || "")}</div>`)
  .join("\n")}
        </div>`;
  } else if (s.type === "list") {
    body = `        <div class="bl">
          <div class="bl-left">
            ${s.kicker ? `<div class="kicker" id="${p}-k">${esc(s.kicker)}</div>` : ""}
            <h2 class="split-title" id="${p}-t">${s.titleHtml || esc(s.title || "")}</h2>
            ${s.desc ? `<p class="split-desc" id="${p}-d">${s.descHtml || esc(s.desc)}</p>` : ""}
          </div>
          <div class="bl-list">
${(s.items || [])
  .map(
    (it, i) => `            <div class="bl-item ${esc(it.tone || "")}" id="${p}-i${i}">
              <span class="bdot">${esc(it.mark || "✓")}</span><span>${it.html || esc(it.text)}</span>
            </div>`
  )
  .join("\n")}
          </div>
        </div>`;
  } else if (s.type === "vs") {
    const col = (c, cls) => `          <div class="vs-col ${cls}" id="${p}-${cls}">
            <div class="vs-name">${esc(c.name)}</div>
            ${c.note ? `<div class="vs-note">${esc(c.note)}</div>` : ""}
            <div class="vs-list">
${(c.items || []).map((x) => `<li>${esc(x)}</li>`).join("\n")}
            </div>
          </div>`;
    body = `        <div class="vs">
${s.title ? `          <div class="vs-head">
            ${s.kicker ? `<div class="kicker" id="${p}-k">${esc(s.kicker)}</div>` : ""}
            <h2 class="h2" id="${p}-t" style="font-size:54px">${esc(s.title)}</h2>
          </div>` : ""}
${col(s.a, "a")}
          <div class="vs-mid" id="${p}-mid">${esc(s.mid || "VS")}</div>
${col(s.b, "b")}
        </div>`;
  } else if (s.type === "chain") {
    const nodes = s.nodes || [];
    const row = nodes
      .map(
        (n, i) =>
          `            <div class="chain-node ${n.tone || ""}" id="${p}-n${i}"><b>${esc(n.name)}</b>${
            n.note ? `<small>${esc(n.note)}</small>` : ""
          }</div>` + (i < nodes.length - 1 ? `\n            <div class="chain-arrow" id="${p}-a${i}">→</div>` : "")
      )
      .join("\n");
    body = `        <div class="chain">
          <div class="chain-head">
            ${s.kicker ? `<div class="kicker" id="${p}-k">${esc(s.kicker)}</div>` : ""}
            <h2 class="h2" id="${p}-t">${s.titleHtml || esc(s.title || "")}</h2>
            ${s.desc ? `<p class="split-desc" id="${p}-d">${esc(s.desc)}</p>` : ""}
          </div>
          <div class="chain-row">
${row}
          </div>
        </div>`;
  } else if (s.type === "end") {
    body = `        <div class="end-wrap">
${(s.lines || [])
  .map((l, i) => `          <div class="end-big ${esc(l.cls || "")}" id="${p}-l${i}">${l.html || esc(l.text || "")}</div>`)
  .join("\n")}
          ${s.sub ? `<div class="end-sub" id="${p}-s">${esc(s.sub)}</div>` : ""}
          ${s.sign ? `<div class="end-sign" id="${p}-sign">${esc(s.sign)}</div>` : ""}
        </div>`;
  }

  /* 场景内的 IP 大形象（可选）：s.ip 指定素材名，s.ipStyle 给位置尺寸 */
  const ipHtml = s.ip
    ? `\n        <div class="ip-hero" id="${p}-ip" style="${esc(s.ipStyle || "")}"><img src="assets/mascot/${esc(s.ip)}.png" alt="" /></div>`
    : "";

  return sceneWrap(p, s.start, s.end - s.start, body + ipHtml, `t-${s.type}`);
};

const sceneMarkup = SCENES2.map(sceneHtml).join("\n");

/** 一个场景内的入场动画：按 type 走不同节奏，时间点都相对场景起点 */
function sceneAnim(s) {
  const p = s.id;
  const t0 = Number(s.start);
  const rel = (x) => f3(Math.max(t0, Number(x)));

  if (s.type === "chapter") {
    if (s.instant) {
      /* 首场景：t=0 就完整在位，只做位移收位，不做淡入（平台抽第一帧当封面） */
      push(`tl.fromTo("#${p}-no", { y: 22 }, { y: 0, duration: 0.6, ease: "power2.out" }, 0);`);
      push(`tl.fromTo("#${p}-t", { y: 26 }, { y: 0, duration: 0.68, ease: "power3.out" }, 0);`);
      if (s.sub) push(`tl.fromTo("#${p}-s", { y: 14 }, { y: 0, duration: 0.52 }, 0);`);
      push(`tl.fromTo("#${p}-r", { scaleX: 0.4 }, { scaleX: 1, duration: 0.72, ease: "power2.out" }, 0);`);
    } else {
    push(`tl.fromTo("#${p}-no", { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${rel(t0 + 0.06)});`);
    push(`tl.fromTo("#${p}-t", { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.55, ease: "power3.out" }, ${rel(t0 + 0.18)});`);
    if (s.sub) push(`tl.fromTo("#${p}-s", { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.45 }, ${rel(t0 + 0.42)});`);
    push(`tl.fromTo("#${p}-r", { scaleX: 0.3 }, { scaleX: 1, duration: 0.6, ease: "power2.out" }, ${rel(t0 + 0.5)});`);
    }
  }

  if (s.type === "quad") {
    push(`tl.fromTo("#${p}-k", { opacity: 0, x: -16 }, { opacity: 1, x: 0, duration: 0.4 }, ${rel(t0 + 0.05)});`);
    push(`tl.fromTo("#${p}-t", { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, ${rel(t0 + 0.14)});`);
    (s.items || []).forEach((it, i) => {
      const at = Number(it.at || t0);
      push(`tl.set("#${p}-c${i}", { opacity: 0.36 }, 0);`);
      push(`tl.to("#${p}-c${i}", { opacity: 1, duration: 0.42, ease: "power2.out" }, ${rel(at)});`);
      push(`tl.fromTo("#${p}-c${i}", { scale: 0.965 }, { scale: 1, duration: 0.5, ease: "back.out(1.8)" }, ${rel(at)});`);
      (it.tags || []).forEach((_, j) => {
        push(`tl.set("#${p}-c${i}-t${j}", { opacity: 0, y: 6 }, 0);`);
        push(`tl.to("#${p}-c${i}-t${j}", { opacity: 1, y: 0, duration: 0.28 }, ${rel(at + 0.3 + j * 0.16)});`);
      });
    });
  }

  if (s.type === "punch") {
    (s.lines || []).forEach((l, i) => {
      const at = Number(l.at || t0 + 0.1 + i * 0.6);
      if (s.instant) {
        push(`tl.fromTo("#${p}-l${i}", { y: 20 }, { y: 0, duration: 0.62, ease: "power3.out" }, ${rel(at)});`);
      } else {
        push(`tl.fromTo("#${p}-l${i}", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, ${rel(at)});`);
      }
    });
  }

  if (s.type === "list") {
    if (s.kicker) push(`tl.fromTo("#${p}-k", { opacity: 0, x: -16 }, { opacity: 1, x: 0, duration: 0.36 }, ${rel(t0 + 0.02)});`);
    push(`tl.fromTo("#${p}-t", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.46, ease: "power3.out" }, ${rel(t0 + 0.06)});`);
    if (s.desc) push(`tl.fromTo("#${p}-d", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.4 }, ${rel(t0 + 0.22)});`);
    (s.items || []).forEach((it, i) => {
      const at = Number(it.at || t0 + 0.5 + i * 0.55);
      push(`tl.fromTo("#${p}-i${i}", { opacity: 0, x: 34 }, { opacity: 1, x: 0, duration: 0.46, ease: "back.out(1.5)" }, ${rel(at)});`);
    });
  }

  if (s.type === "vs") {
    if (s.title) push(`tl.fromTo("#${p}-t", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, ${rel(t0 + 0.1)});`);
    push(`tl.fromTo("#${p}-a", { opacity: 0, x: -46 }, { opacity: 1, x: 0, duration: 0.55, ease: "back.out(1.4)" }, ${rel(t0 + 0.1)});`);
    push(`tl.fromTo("#${p}-mid", { opacity: 0, scale: 0.7 }, { opacity: 1, scale: 1, duration: 0.4, ease: "back.out(2)" }, ${rel(t0 + 0.5)});`);
    push(`tl.fromTo("#${p}-b", { opacity: 0, x: 46 }, { opacity: 1, x: 0, duration: 0.55, ease: "back.out(1.4)" }, ${rel(t0 + 0.75)});`);
    (s.beats || []).forEach((b, i) => {
      const at = Number(b.at || t0 + 1.4 + i * 1.2);
      push(`tl.fromTo("#${p}-${b.sel}", { scale: 1 }, { scale: 1.045, duration: 0.34, yoyo: true, repeat: 1, ease: "sine.inOut" }, ${rel(at)});`);
    });
  }

  if (s.type === "chain") {
    if (s.kicker) push(`tl.fromTo("#${p}-k", { opacity: 0, x: -16 }, { opacity: 1, x: 0, duration: 0.4 }, ${rel(t0 + 0.05)});`);
    push(`tl.fromTo("#${p}-t", { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, ${rel(t0 + 0.14)});`);
    if (s.desc) push(`tl.fromTo("#${p}-d", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.42 }, ${rel(t0 + 0.36)});`);
    const nodes = s.nodes || [];
    nodes.forEach((n, i) => {
      const at = Number(n.at || t0 + 0.5 + i * 0.5);
      /* 先说到的节点先亮：没轮到的先给一个暗态占位，否则链条中段会空一大块 */
      push(`tl.set("#${p}-n${i}", { opacity: 0.26 }, 0);`);
      push(
        `tl.fromTo("#${p}-n${i}", { y: 26, scale: 0.94, opacity: 1 }, { y: 0, scale: 1, opacity: 1, duration: 0.48, ease: "back.out(1.5)", immediateRender: false }, ${rel(at)});`
      );
      if (i < nodes.length - 1) {
        push(`tl.fromTo("#${p}-a${i}", { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1, duration: 0.3 }, ${rel(at + 0.28)});`);
      }
    });
  }

  if (s.type === "end") {
    (s.lines || []).forEach((l, i) => {
      const at = Number(l.at || t0 + 0.2 + i * 0.7);
      push(`tl.fromTo("#${p}-l${i}", { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: 0.55, ease: "power3.out" }, ${rel(at)});`);
    });
    if (s.sub) push(`tl.fromTo("#${p}-s", { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.45 }, ${rel(t0 + 1.5)});`);
    if (s.sign) push(`tl.fromTo("#${p}-sign", { opacity: 0, y: 14, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.6)" }, ${rel(t0 + 1.9)});`);
  }

  /* 场景内的 IP 大形象 */
  if (s.ip) {
    if (s.instant) {
      /* 首帧就要在，不能淡入 */
      push(`tl.fromTo("#${p}-ip", { scale: 1.06 }, { scale: 1, duration: 0.8, ease: "power2.out" }, 0);`);
    } else {
      push(`tl.fromTo("#${p}-ip", { opacity: 0, y: 30, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.72, ease: "back.out(1.35)" }, ${rel(t0 + 0.55)});`);
    }
    push(`tl.to("#${p}-ip", { y: -10, duration: 1.7, yoyo: true, repeat: 8, ease: "sine.inOut" }, ${rel(t0 + 1.3)});`);
  }
}

/* ══════════════ GSAP 时间线 ══════════════ */
const L = [];
const push = (s) => L.push("      " + s);

/* 场景进出（预览与渲染一致，避免多场景叠在一起） */
const BASE_BOUNDS = [
  ["#s1", 0, B.s2],
  ["#s2", B.s2, B.s3],
  ["#s3", B.s3, B.s4],
  ["#s4", B.s4, B.s5],
  ["#s5", B.s5, B.s6],
  ["#s6", B.s6, B.s7],
];
const SCENE_BOUNDS = [
  ...(BASE ? BASE_BOUNDS : []),
  ...SCENES2.map((s) => ["#" + s.id, Number(s.start), Number(s.end)]),
];
/* 第一个场景必须 t=0 就在位：平台抽第一帧当封面，不能从透明淡进来 */
if (SCENE_BOUNDS.length) push(`tl.set("${SCENE_BOUNDS[0][0]}", { opacity: 1 }, 0);`);
SCENE_BOUNDS.slice(1).forEach(([sel, st, en]) => {
  push(`tl.fromTo("${sel}", { opacity: 0 }, { opacity: 1, duration: 0.22, ease: "power1.out" }, ${f3(st)});`);
});
SCENE_BOUNDS.forEach(([sel, st, en]) => {
  push(`tl.to("${sel}", { opacity: 0, duration: 0.2, ease: "power1.in" }, ${f3(Math.max(st + 0.3, en - 0.2))});`);
});

/* ══════════════ 个人 IP 形象动画 ══════════════ */
/* L1 背景底纹：极缓漂浮，全片都在。半透明埋在深处，裁切/截图都去不掉 */
push(`tl.set("#ipbg .b1", { rotation: -9, transformOrigin: "center center" }, 0);`);
push(`tl.set("#ipbg .b2", { rotation: 8, transformOrigin: "center center" }, 0);`);
push(`tl.to("#ipbg .b1", { y: -22, rotation: -6, duration: 5.4, yoyo: true, repeat: 9, ease: "sine.inOut" }, 0);`);
push(`tl.to("#ipbg .b2", { y: 18, rotation: 5, duration: 6.6, yoyo: true, repeat: 7, ease: "sine.inOut" }, 0.7);`);
push(`tl.set("#ipbg .b3", { rotation: 6, transformOrigin: "center center" }, 0);`);
push(`tl.to("#ipbg .b3", { y: -16, rotation: 3, duration: 6.0, yoyo: true, repeat: 8, ease: "sine.inOut" }, 1.4);`);

/* 真人画中画：首帧即在（不淡入），开场轻微收位；外圈光环慢转 */
if (PIP) {
  push(`tl.fromTo("#pip", { scale: 1.05 }, { scale: 1, duration: 0.7, ease: "power2.out", transformOrigin: "center center" }, 0);`);
  push(`tl.to("#pip .pip-glow", { rotation: ${Math.round(DURATION / 12) * 360}, duration: ${f3(Math.round(DURATION / 12) * 12 || 12)}, ease: "none" }, 0);`);
}

/* L2 常驻角标：首帧即在线（平台抽第一帧当封面，IP 必须在），随后轻微浮动 */
push(`tl.fromTo("#ipmark", { y: -14 }, { y: 0, duration: 0.6, ease: "power2.out" }, 0);`);
push(`tl.to("#ipmark .mk-face", { y: 7, duration: 2.6, yoyo: true, repeat: 24, ease: "sine.inOut" }, 1.2);`);
/* 角标表情随场景轮换：微笑 → 眨眼 → 大笑，每次换场景交叉淡换（首帧固定微笑） */
SCENE_BOUNDS.slice(1).forEach(([, st], i) => {
  const cur = (i + 1) % 3, prev = i % 3;
  push(`tl.to("#ipmark .f${prev}", { opacity: 0, duration: 0.3, ease: "power1.inOut" }, ${f3(Number(st) + 0.05)});`);
  push(`tl.to("#ipmark .f${cur}", { opacity: 1, duration: 0.3, ease: "power1.inOut" }, ${f3(Number(st) + 0.05)});`);
});

/* L3 场景内的 IP 演出只属于第一课那几个手写场景 */
if (BASE) {
/* L3-1 封面：首帧已就位，开场做一次收位回弹（不淡入，避免封面缺 IP） */
push(`tl.fromTo("#s1-ip", { scale: 1.06 }, { scale: 1, duration: 0.72, ease: "power2.out" }, 0);`);
push(`tl.to("#s1-ip", { y: -12, duration: 1.5, yoyo: true, repeat: 2, ease: "sine.inOut" }, 1.4);`);

/* L3-2 司机：滑入 + 名牌 */
push(`tl.fromTo("#s5-ip img", { opacity: 0, x: 74 }, { opacity: 1, x: 0, duration: 0.72, ease: "back.out(1.4)" }, ${f3(B.s5 + 0.45)});`);
push(`tl.fromTo("#s5-sign", { opacity: 0, y: 9 }, { opacity: 1, y: 0, duration: 0.42, ease: "power2.out" }, ${f3(B.s5 + 1.05)});`);
push(`tl.to("#s5-ip", { y: -10, duration: 1.25, yoyo: true, repeat: 1, ease: "sine.inOut" }, ${f3(B.s5 + 1.3)});`);

/* L3-3 收尾：形象 + 原创署名 */
push(`tl.fromTo("#s6-ip img", { opacity: 0, x: -64, scale: 0.95 }, { opacity: 1, x: 0, scale: 1, duration: 0.78, ease: "back.out(1.4)" }, ${f3(B.s6 + 0.85)});`);
push(`tl.fromTo("#s6-sign", { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.45, ease: "power2.out" }, ${f3(B.s6 + 1.5)});`);
push(`tl.to("#s6-ip", { y: -9, duration: 1.6, yoyo: true, repeat: 2, ease: "sine.inOut" }, ${f3(B.s6 + 1.7)});`);

/* S1 封面（首帧就要有内容，避免空封面） */
/* 首帧就是完整封面（平台会抽第一帧当封面，不能是半透明的空画面） */
push(`tl.fromTo("#s1-chip", { y: -8 }, { y: 0, duration: 0.5, ease: "power2.out" }, 0);`);
push(`tl.fromTo("#s1-title", { y: 14 }, { y: 0, duration: 0.75, ease: "power3.out" }, 0);`);
push(`tl.fromTo("#s1-rule", { scaleX: 0.62 }, { scaleX: 1, duration: 0.7, ease: "power2.out" }, 0.08);`);
push(`tl.fromTo("#s1-sub", { y: 10 }, { y: 0, duration: 0.6, ease: "power2.out" }, 0.16);`);
push(`tl.fromTo("#s1-icons", { y: 20 }, { y: 0, duration: 0.6, ease: "power2.out" }, 0.85);`);
push(`tl.to(".s1-icon.i1", { scale: 1.07, duration: 0.32, ease: "power2.out" }, 1.45);`);
push(`tl.to(".s1-icon.i2", { scale: 1.07, duration: 0.32, ease: "power2.out" }, 2.05);`);
push(`tl.to(".s1-icon.i3", { scale: 1.07, duration: 0.32, ease: "power2.out" }, 2.65);`);
push(`tl.to("#s1-title, #s1-sub, #s1-icons, #s1-chip, #s1-rule", { opacity: 0, duration: 0.42, ease: "power1.in" }, 5.5);`);

/* S2 三张卡片 + 连线 */
const s2 = B.s2;
push(`tl.fromTo("#s2-title", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s2 + 0.15)});`);
push(`tl.fromTo("#s2-c1", { opacity: 0, y: 40, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s2 + 0.9)});`);
push(`tl.fromTo("#s2-c2", { opacity: 0, y: 40, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s2 + 2.2)});`);
push(`tl.fromTo("#s2-c3", { opacity: 0, y: 40, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s2 + 3.6)});`);
push(`tl.fromTo("#s2-link1 i", { scaleX: 0 }, { scaleX: 1, duration: 0.45, ease: "power2.inOut" }, ${f3(s2 + 3.0)});`);
push(`tl.fromTo("#s2-link2 i", { scaleX: 0 }, { scaleX: 1, duration: 0.45, ease: "power2.inOut" }, ${f3(s2 + 4.4)});`);
push(`tl.fromTo("#s2-q", { opacity: 0, y: 14 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s2 + 5.0)});`);
push(`tl.to("#s2-title, #s2-q", { opacity: 0, duration: 0.4, ease: "power1.in" }, ${f3(B.s3 - 0.55)});`);
push(`tl.to(".s2-row", { opacity: 0, duration: 0.4, ease: "power1.in" }, ${f3(B.s3 - 0.5)});`);

/* S3 发动机 */
const s3 = B.s3;
push(`tl.fromTo("#s3-kicker", { opacity: 0, x: -18 }, { opacity: 1, x: 0, duration: 0.45, ease: "power2.out" }, ${f3(s3 + 0.1)});`);
push(`tl.fromTo("#s3-title", { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: 0.55, ease: "power3.out" }, ${f3(s3 + 0.3)});`);
push(`tl.fromTo("#s3-desc", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s3 + 0.9)});`);
push(`tl.fromTo("#engineArt", { opacity: 0, scale: 0.86 }, { opacity: 1, scale: 1, duration: 0.8, ease: "back.out(1.4)" }, ${f3(s3 + 0.35)});`);
push(`tl.fromTo("#engRing1", { rotation: 0 }, { rotation: 180, duration: ${f3(B.s4 - B.s3)}, ease: "none" }, ${f3(s3)});`);
push(`tl.fromTo("#engRing2", { rotation: 0, scale: 1 }, { rotation: -90, scale: 1.04, duration: ${f3(B.s4 - B.s3)}, ease: "none" }, ${f3(s3)});`);
push(`tl.fromTo("#engBlades", { rotation: 0 }, { rotation: 300, duration: ${f3(B.s4 - B.s3)}, ease: "none" }, ${f3(s3)});`);
push(`tl.fromTo("#engCore", { scale: 1, opacity: 1 }, { scale: 1.2, opacity: 0.82, duration: 0.9, yoyo: true, repeat: 7, ease: "sine.inOut", transformOrigin: "center center" }, ${f3(s3 + 1.2)});`);
/* 品牌标签依次点亮 */
push(`tl.fromTo("#s3-t1", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 15.72);`);
push(`tl.fromTo("#s3-t2", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 17.72);`);
push(`tl.fromTo("#s3-t3", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 18.82);`);
push(`tl.fromTo("#s3-t4", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 19.72);`);
/* “能力特别强”强调 */
push(`tl.fromTo("#s3-punch", { opacity: 0, y: 16, scale: 0.96 }, { opacity: 1, y: 0, scale: 1, duration: 0.45, ease: "back.out(1.8)" }, 22.62);`);
push(`tl.fromTo("#engineHalo", { opacity: 0.28 }, { opacity: 0.85, duration: 0.6, yoyo: true, repeat: 3, ease: "sine.inOut" }, 22.62);`);
push(`tl.to("#s3-kicker, #s3-title, #s3-desc, #s3-tags, #s3-punch", { opacity: 0, duration: 0.4, ease: "power1.in" }, ${f3(B.s4 - 0.5)});`);
push(`tl.to("#engineArt", { opacity: 0, scale: 0.94, duration: 0.42, ease: "power1.in" }, ${f3(B.s4 - 0.45)});`);

/* S4 汽车 */
const s4 = B.s4;
push(`tl.fromTo("#s4-kicker", { opacity: 0, x: -18 }, { opacity: 1, x: 0, duration: 0.45, ease: "power2.out" }, ${f3(s4 + 0.15)});`);
push(`tl.fromTo("#s4-title", { opacity: 0, y: 26 }, { opacity: 1, y: 0, duration: 0.55, ease: "power3.out" }, ${f3(s4 + 0.35)});`);
push(`tl.fromTo("#s4-desc", { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s4 + 1.0)});`);
push(`tl.fromTo("#carArt", { opacity: 0, scale: 0.9 }, { opacity: 1, scale: 1, duration: 0.7, ease: "back.out(1.4)" }, ${f3(s4 + 0.5)});`);
/* 车身描边动画（stroke-dashoffset 从整段到 0） */
push(`tl.fromTo("#carBody", { strokeDasharray: 1200, strokeDashoffset: 1200 }, { strokeDashoffset: 0, duration: 1.5, ease: "power2.inOut" }, ${f3(s4 + 0.6)});`);
push(`tl.fromTo("#carRoof", { strokeDasharray: 480, strokeDashoffset: 480 }, { strokeDashoffset: 0, duration: 0.9, ease: "power2.inOut" }, ${f3(s4 + 1.9)});`);
push(`tl.fromTo("#carGlass", { opacity: 0 }, { opacity: 1, duration: 0.5, ease: "power1.out" }, ${f3(s4 + 2.4)});`);
push(`tl.fromTo("#carBase", { opacity: 0, scaleX: 0.6 }, { opacity: 1, scaleX: 1, duration: 0.55, ease: "power2.out" }, ${f3(s4 + 2.6)});`);
push(`tl.fromTo("#carWheels", { opacity: 0, scale: 0.7 }, { opacity: 1, scale: 1, duration: 0.5, ease: "back.out(2)" }, ${f3(s4 + 2.8)});`);
push(`tl.fromTo("#engineSlot", { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.45, ease: "back.out(1.8)" }, ${f3(s4 + 3.3)});`);
/* 工具标签 */
push(`tl.fromTo("#s4-t1", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 31.5);`);
push(`tl.fromTo("#s4-t2", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 33.3);`);
push(`tl.fromTo("#s4-t3", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 34.68);`);
push(`tl.fromTo("#s4-t4", { opacity: 0, y: 14, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2)" }, 36.6);`);
/* “它只是工具” */
push(`tl.fromTo("#s4-punch", { opacity: 0, y: 16, scale: 0.96 }, { opacity: 1, y: 0, scale: 1, duration: 0.45, ease: "back.out(1.8)" }, 38.1);`);
push(`tl.to("#carBase", { scaleX: 1.04, opacity: 0.55, duration: 0.5, yoyo: true, repeat: 1, ease: "sine.inOut" }, 38.1);`);
push(`tl.to("#s4-kicker, #s4-title, #s4-desc, #s4-tags, #s4-punch", { opacity: 0, duration: 0.4, ease: "power1.in" }, ${f3(B.s5 - 0.45)});`);
push(`tl.to("#carArt", { opacity: 0, scale: 0.95, duration: 0.4, ease: "power1.in" }, ${f3(B.s5 - 0.4)});`);

/* S5 司机 */
const s5 = B.s5;
push(`tl.fromTo(".s5-art", { opacity: 0, scale: 0.84, rotation: -12 }, { opacity: 1, scale: 1, rotation: 0, duration: 0.6, ease: "back.out(1.6)" }, ${f3(s5 + 0.1)});`);
push(`tl.fromTo("#s5-kicker", { opacity: 0, x: -16 }, { opacity: 1, x: 0, duration: 0.4, ease: "power2.out" }, ${f3(s5 + 0.5)});`);
push(`tl.fromTo("#s5-title", { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, ${f3(s5 + 0.7)});`);
push(`tl.fromTo("#s5-desc", { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.45, ease: "power2.out" }, ${f3(s5 + 1.3)});`);
push(`tl.to("#wheelArt", { rotation: 16, duration: 0.6, yoyo: true, repeat: 1, ease: "sine.inOut", transformOrigin: "center center" }, ${f3(s5 + 0.8)});`);
push(`tl.to("#s5-kicker, #s5-title, #s5-desc", { opacity: 0, duration: 0.35, ease: "power1.in" }, ${f3(B.s6 - 0.4)});`);
push(`tl.to(".s5-art", { opacity: 0, scale: 0.95, duration: 0.35, ease: "power1.in" }, ${f3(B.s6 - 0.35)});`);

/* S6 总图 */
const s6 = B.s6;
push(`tl.fromTo("#s6-title", { opacity: 0, y: 22 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s6 + 0.1)});`);
push(`tl.fromTo("#s6-l1", { opacity: 0, x: -36 }, { opacity: 1, x: 0, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s6 + 0.75)});`);
push(`tl.fromTo("#s6-a1", { opacity: 0, y: -8 }, { opacity: 1, y: 0, duration: 0.3, ease: "power2.out" }, ${f3(s6 + 1.2)});`);
push(`tl.fromTo("#s6-l2", { opacity: 0, x: -36 }, { opacity: 1, x: 0, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s6 + 1.55)});`);
push(`tl.fromTo("#s6-a2", { opacity: 0, y: -8 }, { opacity: 1, y: 0, duration: 0.3, ease: "power2.out" }, ${f3(s6 + 2.0)});`);
push(`tl.fromTo("#s6-l3", { opacity: 0, x: -36 }, { opacity: 1, x: 0, duration: 0.5, ease: "back.out(1.5)" }, ${f3(s6 + 2.35)});`);
push(`tl.fromTo("#s6-end", { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" }, ${f3(s6 + 3.4)});`);
} /* ← 结束：第一课手写场景动画 */

/* 逐词高亮字幕 */
const HILITE = `{ color: "#0B63F6" }`;
const REST = `{ color: "#10305F" }`;
captions.forEach((c, i) => {
  if (i > 0) push(`tl.set("#cap-${i - 1}", { opacity: 0 }, ${f3(c.start)});`);
  push(`tl.fromTo("#cap-${i}", { opacity: 0, y: 10 }, { opacity: 1, y: 0, duration: 0.14, ease: "power2.out" }, ${f3(c.start)});`);
  const words = Array.isArray(c.words) && c.words.length ? c.words : [{ t: c.text, s: c.start, e: c.end }];
  words.forEach((w, j) => {
    const id = `#w-${i}-${j}`;
    push(`tl.set("${id}", ${HILITE}, ${f3(w.s)});`);
    push(`tl.fromTo("${id}", { y: 0 }, { y: -4, duration: 0.06, yoyo: true, repeat: 1, ease: "power2.out" }, ${f3(w.s)});`);
    push(`tl.set("${id}", ${REST}, ${f3(w.e)});`);
  });
});

/* 进度条 */
push(`tl.fromTo("#progress-fill", { scaleX: 0 }, { scaleX: 1, duration: ${f3(DURATION)}, ease: "none" }, 0);`);
push(`tl.fromTo("#progress-dot", { x: 0 }, { x: ${W - 14}, duration: ${f3(DURATION)}, ease: "none" }, 0);`);

/* 注册（纯浏览器打开时 __timelines 不存在，先兜底建一个，渲染器会自己注入） */
push(`window.__timelines = window.__timelines || {};`);
push(`window.__timelines["main"] = tl;`);
push(
  `const _qs = new URLSearchParams(location.search);` +
    `if (_qs.has("t")) { tl.seek(Number(_qs.get("t")) || 0); tl.pause(); }` +
    `else if (_qs.has("preview")) { tl.play(0); tl.eventCallback("onComplete", () => tl.play(0)); }`
);
/* 诊断：带 ?t= 时把真实时间写进 title，便于外部核对 seek 是否生效 */
push(`if (_qs.has("t")) { document.title = "DIAG t=" + tl.time().toFixed(2) + " q=" + location.search; }`);

/* ══════════════ 第二章起：各场景入场动画 ══════════════ */
SCENES2.forEach(sceneAnim);

/* ══════════════ HTML ══════════════ */
const html = `<!doctype html>
<html lang="zh-CN">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=${W}, height=${H}" />
    <title>${esc(cfg.title || "知识动画")}</title>
    <script src="assets/gsap.min.js"></script>
    <style>
      @font-face { font-family: "PingFang SC"; src: local("PingFang SC"), local("PingFangSC-Regular"); }
      @font-face { font-family: "Microsoft YaHei"; src: local("Microsoft YaHei"), local("MicrosoftYaHei"); }
      * { margin: 0; padding: 0; box-sizing: border-box; }
      html, body { margin: 0; width: ${W}px; height: ${H}px; overflow: hidden; background: #E9F1FF; }
      body { font-family: "PingFang SC", "Microsoft YaHei", system-ui, sans-serif; -webkit-font-smoothing: antialiased; }

      #root {
        position: relative; width: ${W}px; height: ${H}px; overflow: hidden;
        background:
          radial-gradient(ellipse 70% 58% at 20% 14%, #FFFFFF 0%, rgba(255,255,255,0) 58%),
          linear-gradient(152deg, #F6FAFF 0%, #E8F1FF 48%, #DEEBFF 100%);
      }
      .bg-glow { position: absolute; border-radius: 50%; filter: blur(90px); z-index: 0; }
      #glow1 { width: 760px; height: 760px; left: -160px; top: -220px; background: rgba(59,130,246,0.22); }
      #glow2 { width: 620px; height: 620px; right: -140px; bottom: -180px; background: rgba(15,181,160,0.20); }
      #dots {
        position: absolute; inset: 0; z-index: 0; opacity: 0.5;
        background-image: radial-gradient(rgba(27,107,255,0.18) 1.2px, transparent 1.2px);
        background-size: 34px 34px;
        mask-image: radial-gradient(ellipse 62% 58% at 50% 46%, #000 0%, transparent 78%);
        -webkit-mask-image: radial-gradient(ellipse 62% 58% at 50% 46%, #000 0%, transparent 78%);
      }

      /* ---- 顶部栏 ---- */
      #topbar { position: absolute; left: 96px; right: 96px; top: 54px; z-index: 8;
                display: flex; align-items: center; justify-content: space-between; }
      #brand { font-size: 30px; font-weight: 700; color: #24406E; letter-spacing: 0.02em;
               display: flex; align-items: center; gap: 12px; }
      #brand .bdot { width: 13px; height: 13px; border-radius: 50%; background: #0FB5A0;
                     box-shadow: 0 0 0 5px rgba(15,181,160,0.18); }
      #chapter { font-size: 28px; font-weight: 600; color: #5B7091; letter-spacing: 0.08em; }
      #toprule { position: absolute; left: 96px; right: 96px; top: 108px; height: 1px;
                 background: linear-gradient(90deg, rgba(27,107,255,0.34), rgba(27,107,255,0.06)); z-index: 8; }

      /* ---- 场景通用 ---- */
      .scene { position: absolute; left: 0; top: 0; width: ${W}px; height: ${H}px; z-index: 3; opacity: 0; }
      .h2 { font-size: 60px; font-weight: 800; color: #10305F; letter-spacing: -0.01em; }
      .kicker { font-size: 28px; font-weight: 700; color: #1B6BFF; letter-spacing: 0.14em; margin-bottom: 16px; }
      .split-title { font-size: 76px; font-weight: 800; color: #10305F; letter-spacing: -0.02em; line-height: 1.14; }
      .split-desc { font-size: 34px; font-weight: 500; color: #44597C; line-height: 1.62; margin-top: 22px; }

      .split { position: absolute; inset: 0; display: flex; align-items: center; padding: 0 96px; gap: 40px; }
      .split-left { width: 44%; padding-top: 20px; }
      .split-right { flex: 1; display: flex; align-items: center; justify-content: center; }

      /* ---- 图形容器 ---- */
      .art { position: relative; display: flex; align-items: center; justify-content: center; }
      .art-svg { width: 100%; height: auto; position: relative; z-index: 2; }
      .eng-stage { position: relative; width: 560px; height: 560px; }
      .eng-ring { position: absolute; border-radius: 50%; }
      .eng-ring-1 { inset: 0; border: 2px dashed rgba(27,107,255,0.30); }
      .eng-ring-2 { inset: 62px; border: 2px solid rgba(27,107,255,0.34); }
      .eng-blades { position: absolute; inset: 0; }
      .eng-blades i {
        position: absolute; left: 50%; top: 50%; width: 15px; height: 62px;
        margin-left: -7.5px; margin-top: -31px;
        background: linear-gradient(180deg, #1B6BFF, rgba(27,107,255,0.55));
        border-radius: 9px;
        transform: rotate(var(--a)) translateY(-196px);
      }
      .eng-hub { position: absolute; left: 50%; top: 50%; width: 136px; height: 136px;
                 margin-left: -68px; margin-top: -68px; border-radius: 50%;
                 background: #FFFFFF; border: 3px solid rgba(27,107,255,0.5);
                 display: flex; align-items: center; justify-content: center;
                 box-shadow: 0 0 40px rgba(27,107,255,0.25); }
      .eng-core { width: 62px; height: 62px; border-radius: 50%; background: #1B6BFF; }
      .art-halo { position: absolute; width: 74%; height: 74%; border-radius: 50%;
                  background: radial-gradient(circle, rgba(27,107,255,0.30) 0%, rgba(27,107,255,0) 68%);
                  filter: blur(26px); z-index: 1; }
      #engineArt { width: 620px; }
      #carArt { width: 680px; flex-direction: column; }
      #carArt .art-halo { background: radial-gradient(circle, rgba(15,181,160,0.28) 0%, rgba(15,181,160,0) 68%); }
      .engine-slot { margin-top: -6px; padding: 8px 24px; border-radius: 999px;
                     background: rgba(15,181,160,0.13); border: 1.5px dashed rgba(15,181,160,0.75);
                     color: #0A8877; font-size: 28px; font-weight: 700; }

      /* ---- S1 ---- */
      .s1-wrap { position: absolute; inset: 0; display: flex; flex-direction: column;
                 align-items: center; justify-content: center; padding-bottom: 60px; }
      .chip { display: inline-flex; align-items: center; gap: 10px; padding: 11px 26px; border-radius: 999px;
              background: rgba(15,181,160,0.13); color: #0A8877; font-size: 28px; font-weight: 700; }
      .chip .dot { width: 11px; height: 11px; border-radius: 50%; background: #0FB5A0; }
      .s1-title { font-size: 118px; font-weight: 900; color: #10305F; letter-spacing: 0.01em;
                  margin-top: 30px; line-height: 1.1; }
      .s1-title .sep { color: #1B6BFF; margin: 0 18px; }
      .s1-rule { width: 340px; height: 7px; border-radius: 99px; margin-top: 26px; transform-origin: center center;
                 background: linear-gradient(90deg, #1B6BFF, #0FB5A0); }
      .s1-sub { font-size: 38px; font-weight: 500; color: #44597C; margin-top: 28px; letter-spacing: 0.02em; }
      .s1-icons { display: flex; gap: 56px; margin-top: 54px; }
      .s1-icon { display: flex; flex-direction: column; align-items: center; gap: 10px;
                 color: #10305F; font-size: 28px; font-weight: 700; }
      .s1-icon .ico { width: 66px; height: 66px; }
      .s1-icon.i1 .ico { color: #1B6BFF; }
      .s1-icon.i2 .ico { color: #0FB5A0; }
      .s1-icon.i3 .ico { color: #F59E0B; }
      .ico { display: block; }

      /* ---- S2 ---- */
      .s2-wrap { position: absolute; inset: 0; display: flex; flex-direction: column;
                 align-items: center; justify-content: center; padding: 40px 96px 120px; }
      .s2-row { display: flex; align-items: center; gap: 18px; margin-top: 62px; }
      .s2-card { width: 336px; padding: 42px 26px 34px; border-radius: 30px; text-align: center;
                 background: #FFFFFF; border: 2px solid rgba(27,107,255,0.13);
                 box-shadow: 0 22px 50px rgba(21,58,120,0.12); }
      .s2-card .s2-ico { width: 96px; height: 96px; margin: 0 auto 22px; }
      .s2-card .s2-ico .ico { width: 96px; height: 96px; }
      .s2-card.c-blue { color: #1B6BFF; }
      .s2-card.c-teal { color: #0FB5A0; }
      .s2-card.c-amber { color: #D98A07; }
      .s2-name { font-size: 40px; font-weight: 800; color: #10305F; }
      .s2-note { font-size: 28px; font-weight: 500; color: #5B7091; margin-top: 10px; }
      .s2-link { width: 76px; height: 3px; position: relative; }
      .s2-link i { display: block; width: 100%; height: 3px; border-radius: 99px; transform-origin: left center;
                   background: repeating-linear-gradient(90deg, rgba(27,107,255,0.55) 0 10px, transparent 10px 20px); }
      .s2-q { margin-top: 62px; font-size: 32px; font-weight: 600; color: #44597C; }

      /* ---- 标签 ---- */
      .tags { display: flex; flex-wrap: wrap; gap: 14px; margin-top: 40px; max-width: 620px; }
      .tag { padding: 11px 26px; border-radius: 999px; font-size: 28px; font-weight: 700; }
      .t-blue { background: rgba(27,107,255,0.11); color: #1053C8; border: 1.5px solid rgba(27,107,255,0.32); }
      .t-teal { background: rgba(15,181,160,0.12); color: #0A8877; border: 1.5px solid rgba(15,181,160,0.38); }

      /* ---- 强调条 ---- */
      .punch { display: inline-flex; margin-top: 34px; padding: 14px 32px; border-radius: 16px;
               background: #1B6BFF; color: #FFFFFF; font-size: 30px; font-weight: 800;
               box-shadow: 0 14px 32px rgba(27,107,255,0.32); }
      .punch-teal { background: #0A8877; box-shadow: 0 14px 32px rgba(15,181,160,0.32); }

      /* ---- S5 ---- */
      .s5-wrap { position: absolute; inset: 0; display: flex; align-items: center;
                 justify-content: center; gap: 90px; padding: 0 96px; }
      .s5-art { width: 400px; }
      .s5-art .art-svg { width: 100%; }
      .s5-art .art-halo { background: radial-gradient(circle, rgba(245,158,11,0.30) 0%, rgba(245,158,11,0) 68%); }
      .s5-text { max-width: 760px; }

      /* ---- S6 ---- */
      .s6-wrap { position: absolute; inset: 0; display: flex; flex-direction: column;
                 align-items: center; justify-content: center; padding: 128px 96px 175px; }
      .s6-title { font-size: 50px; font-weight: 800; color: #10305F; }
      .stack { display: flex; flex-direction: column; align-items: center; margin-top: 26px; }
      .layer { display: flex; align-items: center; gap: 24px; width: 760px; padding: 16px 32px;
               border-radius: 24px; background: #FFFFFF; border: 2px solid rgba(27,107,255,0.13);
               box-shadow: 0 18px 42px rgba(21,58,120,0.11); }
      .layer .layer-ico .ico { width: 54px; height: 54px; display: block; }
      .layer-txt b { display: block; font-size: 36px; font-weight: 800; color: #10305F; }
      .layer-txt span { display: block; font-size: 28px; font-weight: 500; color: #5B7091; margin-top: 2px; }
      .l-blue .layer-ico { color: #1B6BFF; }
      .l-teal .layer-ico { color: #0FB5A0; }
      .l-amber .layer-ico { color: #D98A07; }
      .arrow { font-size: 32px; color: #5578B8; line-height: 1; margin: 4px 0; }
      .s6-end { margin-top: 26px; font-size: 34px; font-weight: 800; color: #0A8877;
                padding: 12px 32px; border-radius: 999px; background: rgba(15,181,160,0.13); }

      /* ══════ 第二章起：通用场景组件 ══════ */
      /* --- 章节卡 --- */
      .ch { position: absolute; inset: 0; display: flex; flex-direction: column;
            align-items: center; justify-content: center; padding-bottom: 40px; }
      .ch-no { font-size: 118px; font-weight: 900; color: #3E6FD0;
               letter-spacing: 0.05em; line-height: 1; }
      .ch-title { font-size: 90px; font-weight: 900; color: #10305F; letter-spacing: -0.01em; margin-top: 10px; }
      .ch-sub { font-size: 34px; font-weight: 500; color: #44597C; margin-top: 26px; letter-spacing: 0.02em; }
      .ch-rule { width: 280px; height: 6px; border-radius: 99px; margin-top: 32px; transform-origin: center center;
                 background: linear-gradient(90deg, #1B6BFF, #0FB5A0); }

      /* --- 四宫格 --- */
      .quad { position: absolute; inset: 0; display: flex; flex-direction: column;
              justify-content: center; padding: 132px 96px 128px; }
      .quad-head { text-align: center; margin-bottom: 40px; }
      .quad-head .h2 { font-size: 56px; }
      .q-grid { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr; gap: 26px; }
      .q-card { background: #FFFFFF; border: 2px solid rgba(27,107,255,0.12); border-radius: 26px;
                padding: 26px 30px 24px; box-shadow: 0 14px 34px rgba(21,58,120,0.08); }
      .q-top { display: flex; align-items: center; gap: 16px; }
      .q-ico { width: 54px; height: 54px; flex: 0 0 54px; color: #1B6BFF; }
      .q-ico .ico { width: 54px; height: 54px; }
      .q-name { font-size: 36px; font-weight: 800; color: #10305F; line-height: 1.2; }
      .q-note { font-size: 28px; font-weight: 500; color: #5B7091; margin-top: 3px; }
      .q-tags { display: flex; flex-wrap: wrap; gap: 9px; margin-top: 15px; }
      .q-tags span { font-size: 28px; font-weight: 700; padding: 5px 14px; border-radius: 999px;
                     background: rgba(27,107,255,0.09); color: #1B6BFF; white-space: nowrap; }
      .q-card.t-teal .q-ico { color: #0FB5A0; }
      .q-card.t-teal .q-tags span { background: rgba(15,181,160,0.11); color: #0A8877; }
      .q-card.t-amber .q-ico { color: #D98A07; }
      .q-card.t-amber .q-tags span { background: rgba(245,158,11,0.13); color: #A96A02; }
      .q-card.t-violet .q-ico { color: #7C5CFF; }
      .q-card.t-violet .q-tags span { background: rgba(124,92,255,0.11); color: #5B3FD6; }

      /* --- 金句 --- */
      .pw { position: absolute; inset: 0; display: flex; flex-direction: column;
            align-items: center; justify-content: center; gap: 22px; padding: 140px 110px 130px; }
      .pw::before { content: "“"; position: absolute; left: 50%; top: 38%; transform: translate(-50%, -50%);
                    font-size: 520px; font-weight: 900; color: rgba(27,107,255,0.06);
                    line-height: 1; pointer-events: none; font-family: Georgia, serif; }
      .pw-q { font-size: 52px; font-weight: 700; color: #6B7D9C; text-align: center; }
      .pw-line { font-size: 84px; font-weight: 900; letter-spacing: -0.01em; line-height: 1.24; text-align: center; }
      .pw-line.no { color: #5B7091; }
      .pw-line.no em { color: #5B7091; text-decoration: line-through; text-decoration-thickness: 6px;
                        text-decoration-color: #E2574C; }
      .pw-line.yes { color: #10305F; }
      .pw-line em { font-style: normal; color: #1B6BFF; }
      .pw-line em.teal { color: #0A8877; }
      .pw-kicker { font-size: 28px; font-weight: 800; color: #1B6BFF; letter-spacing: 0.16em; }

      /* --- 要点清单 --- */
      .bl { position: absolute; inset: 0; display: flex; align-items: center;
            padding: 146px 104px 132px; gap: 54px; }
      .bl-left { width: 39%; }
      .bl-left .split-title { font-size: 66px; }
      .bl-list { flex: 1; display: flex; flex-direction: column; gap: 18px; }
      .bl-item { display: flex; align-items: center; gap: 18px; background: #FFFFFF;
                 border: 2px solid rgba(27,107,255,0.12); border-radius: 22px;
                 padding: 19px 26px; box-shadow: 0 12px 28px rgba(21,58,120,0.07); }
      .bl-item .bdot { width: 34px; height: 34px; border-radius: 50%; flex: 0 0 34px;
                       background: rgba(27,107,255,0.12); color: #1B6BFF; font-size: 19px; font-weight: 900;
                       display: flex; align-items: center; justify-content: center; }
      .bl-item span { font-size: 31px; font-weight: 700; color: #10305F; line-height: 1.3; }
      .bl-item.teal { border-color: rgba(15,181,160,0.22); }
      .bl-item.teal .bdot { background: rgba(15,181,160,0.14); color: #0A8877; }

      /* --- 左右对比 --- */
      .vs { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
            padding: 252px 88px 128px; gap: 24px; }
      .vs-head { position: absolute; left: 0; right: 0; top: 146px; text-align: center; }
      .vs-col { flex: 1; background: #FFFFFF; border-radius: 28px; padding: 36px 34px; min-height: 392px;
                display: flex; flex-direction: column; justify-content: center;
                border: 2px solid rgba(27,107,255,0.14); box-shadow: 0 18px 40px rgba(21,58,120,0.10); }
      .vs-col.a { border-color: rgba(15,181,160,0.34); }
      .vs-name { font-size: 48px; font-weight: 900; color: #10305F; letter-spacing: -0.01em; }
      .vs-note { font-size: 28px; font-weight: 600; color: #5B7091; margin-top: 7px; }
      .vs-list { margin-top: 20px; display: flex; flex-direction: column; gap: 13px; }
      .vs-list li { list-style: none; font-size: 28px; font-weight: 600; color: #24406E;
                    display: flex; gap: 12px; align-items: flex-start; line-height: 1.34; }
      .vs-list li::before { content: ""; width: 9px; height: 9px; border-radius: 50%;
                            background: #1B6BFF; margin-top: 13px; flex: 0 0 9px; }
      .vs-col.a .vs-list li::before { background: #0FB5A0; }
      .vs-mid { font-size: 34px; font-weight: 900; color: #5B7091; letter-spacing: 0.02em;
                background: #FFFFFF; border-radius: 999px; padding: 12px 18px;
                box-shadow: 0 8px 20px rgba(21,58,120,0.10); flex: 0 0 auto; }

      /* --- 流程链 --- */
      .chain { position: absolute; inset: 0; display: flex; flex-direction: column;
               align-items: center; justify-content: center; gap: 40px; padding: 210px 88px 170px; }
      .chain-head { text-align: center; }
      .chain-row { display: flex; align-items: stretch; gap: 16px; flex-wrap: nowrap; width: 100%; justify-content: center; }
      .chain-node { background: #FFFFFF; border: 2px solid rgba(27,107,255,0.16); border-radius: 24px;
                    padding: 22px 26px; text-align: center; flex: 1 1 0; min-width: 0;
                    box-shadow: 0 14px 32px rgba(21,58,120,0.09); }
      .chain-node b { display: block; font-size: 36px; font-weight: 800; color: #10305F; }
      .chain-node small { display: block; font-size: 30px; font-weight: 600; color: #5B7091; margin-top: 6px; }
      .chain-node.acc { border-color: rgba(27,107,255,0.58); background: rgba(27,107,255,0.07); }
      .chain-node.acc2 { border-color: rgba(15,181,160,0.62); background: rgba(15,181,160,0.10); }
      .chain-arrow { font-size: 34px; color: #1B6BFF; font-weight: 800; flex: 0 0 auto; align-self: center; }

      /* --- 结束卡 --- */
      .end-wrap { position: absolute; inset: 0; display: flex; flex-direction: column;
                  align-items: center; justify-content: center; gap: 16px; padding-bottom: 24px; }
      .end-big { font-size: 80px; font-weight: 900; color: #10305F; letter-spacing: -0.01em; line-height: 1.26; }
      .end-big em { font-style: normal; color: #1B6BFF; }
      /* 第二句起用小一号的收尾行，否则 80px 会压到副标题上 */
      .end-big.sm { font-size: 46px; font-weight: 700; color: #44597C; margin-top: 10px; }
      .end-big.sm em { color: #1B6BFF; }
      .end-sub { font-size: 38px; font-weight: 600; color: #44597C; margin-top: 6px; }
      .end-sign { margin-top: 32px; font-size: 29px; font-weight: 800; color: #0A8877;
                  padding: 12px 30px; border-radius: 999px; background: rgba(15,181,160,0.12); }

      /* ---- 字幕 ---- */
      .caption { position: absolute; left: 8%; right: 8%; bottom: 88px; text-align: center; z-index: 20; }
      .caption-inner { display: inline-block; background: rgba(255,255,255,0.9);
                       border: 1.5px solid rgba(27,107,255,0.16);
                       padding: 12px 30px; border-radius: 18px; font-size: 46px; font-weight: 700;
                       line-height: 1.34; box-shadow: 0 12px 30px rgba(21,58,120,0.10);
                       box-decoration-break: clone; -webkit-box-decoration-break: clone; }
      .caption .w { display: inline-block; white-space: pre; color: #10305F; will-change: transform, color; }

      /* ══════ 个人 IP 形象（品牌属性 + 防搬运） ══════ */
      /* L1 背景底纹：半透明 IP 埋在画面深处，截图裁剪都去不掉 */
      #ipbg { position: absolute; inset: 0; z-index: 1; pointer-events: none; }
      #ipbg img { position: absolute; opacity: 0.075; }
      #ipbg .b1 { width: 250px; height: auto; left: -84px; top: 96px; }
      #ipbg .b2 { width: 236px; height: auto; right: -52px; bottom: 30px; }
      #ipbg .b3 { width: 214px; height: auto; left: -62px; bottom: 96px; }

      /* L2 常驻角标：右上角，全片在线，明确归属 */
      #ipmark { position: absolute; right: 44px; top: 128px; z-index: 26;
                display: flex; flex-direction: column; align-items: center; gap: 2px; }
      /* 头像只露头肩：固定框 + 顶部对齐，三种表情叠放，随场景轮换 */
      #ipmark .mk-face { position: relative; width: 140px; height: 150px; overflow: hidden;
                         filter: drop-shadow(0 8px 14px rgba(21,58,120,0.18)); }
      #ipmark .mk-img { position: absolute; left: 0; top: 0; width: 140px; height: auto; display: block; }
      #ipmark .mk-img.f1, #ipmark .mk-img.f2 { opacity: 0; }
      #ipmark .mk-txt { display: inline-flex; align-items: center; gap: 7px; margin-top: -10px;
                        background: rgba(255,255,255,0.94); border: 1.5px solid rgba(27,107,255,0.18);
                        border-radius: 999px; padding: 6px 15px;
                        box-shadow: 0 8px 20px rgba(21,58,120,0.10); }
      #ipmark .mk-txt b { font-size: 21px; font-weight: 800; color: #10305F; letter-spacing: 0.01em; }
      #ipmark .mk-txt i { width: 4px; height: 4px; border-radius: 50%; background: #0FB5A0; }

      /* L2+ 真人画中画（cfg.pip 开启时）：右上小窗 + 名牌，卡通头像贴在小窗左下角 */
${PIP ? `
      #pip { position: absolute; right: ${PIP_RIGHT}px; top: ${PIP_TOP}px; width: ${PIP.size}px; height: ${PIP.size}px; z-index: 25; }
      #pip .pip-frame { position: absolute; inset: 0; overflow: hidden; background: #DCE6F5;
                        border: 6px solid #FFFFFF; border-radius: 50%; box-shadow: 0 16px 36px rgba(21,58,120,0.22); }
      #pip video { display: block; width: 100%; height: 100%; object-fit: cover; }
      #pip .pip-glow { position: absolute; inset: -9px;
                       border-radius: 50%; background: conic-gradient(from 0deg, #1B6BFF, #0FB5A0, #9B7BFF, #1B6BFF); }
      #pip .pip-name { position: absolute; left: 50%; top: 100%; transform: translate(-50%, -16px); white-space: nowrap;
                       display: inline-flex; align-items: center; gap: 7px; padding: 6px 16px; border-radius: 999px;
                       background: rgba(255,255,255,0.96); border: 1.5px solid rgba(27,107,255,0.18);
                       box-shadow: 0 8px 20px rgba(21,58,120,0.12); }
      #pip .pip-name b { font-size: 22px; font-weight: 800; color: #10305F; }
      #pip .pip-name i { width: 5px; height: 5px; border-radius: 50%; background: #0FB5A0; }
      #pip .pip-name span { font-size: 18px; font-weight: 600; color: #5B7091; }
      /* 卡通头像缩小，贴到小窗左下角；名牌改由小窗负责 */
      #ipmark.with-pip { right: ${PIP_RIGHT + PIP.size - 62}px; top: ${PIP_TOP + PIP.size - 112}px; }
      #ipmark.with-pip .mk-face { width: 96px; height: 104px; }
      #ipmark.with-pip .mk-img { width: 96px; }
      #ipmark.with-pip .mk-txt { display: none; }
` : ""}
      /* L3 场景演出：封面 / 司机 / 收尾 三处大形象 */
      .ip-hero { position: absolute; z-index: 6; }
      .ip-hero img { display: block; width: 100%; height: auto;
                     filter: drop-shadow(0 26px 46px rgba(21,58,120,0.24)); }
      #s1-ip { right: 96px; bottom: 150px; width: 300px; }
      #s5-ip { right: 70px; top: 50%; margin-top: -170px; width: 250px; }
      #s6-ip { left: 90px; top: 50%; margin-top: -270px; width: 240px; }
      .ip-sign { margin-top: 16px; text-align: center; font-size: 28px; font-weight: 800;
                 color: #24406E; letter-spacing: 0.04em; opacity: 0; }
      .ip-sign em { font-style: normal; color: #0A8877; }
      .ip-hero .ip-sign { white-space: nowrap; margin-left: -80px; margin-right: -80px; }

      /* ---- 进度条 ---- */
      #progress-track { position: absolute; left: 0; bottom: 0; width: 100%; height: 7px;
                        background: rgba(27,107,255,0.12); z-index: 30; }
      #progress-fill { position: absolute; inset: 0; transform-origin: left center; transform: scaleX(0);
                       background: linear-gradient(90deg, #1B6BFF, #0FB5A0); }
      #progress-dot { position: absolute; bottom: -3px; left: 0; width: 14px; height: 14px; border-radius: 50%;
                      background: #FFFFFF; box-shadow: 0 0 0 3px rgba(27,107,255,0.45); z-index: 31; }
    </style>
  </head>
  <body>
    <div id="root" data-composition-id="main" data-start="0" data-duration="${f3(DURATION)}"
         data-width="${W}" data-height="${H}">

      <audio id="vo" src="${esc(AUDIO)}" data-start="0" data-duration="${f3(DURATION)}" data-track-index="0"></audio>

      <div id="glow1" class="bg-glow" data-layout-ignore></div>
      <div id="glow2" class="bg-glow" data-layout-ignore></div>
      <div id="dots" data-layout-ignore></div>

      <!-- L1 背景 IP 底纹：半透明、埋在最里层 -->
      <div id="ipbg" data-layout-ignore>
        <img class="b1" src="assets/mascot/mia-wink.png" alt="" />
        <img class="b2" src="assets/mascot/mia-laugh.png" alt="" />
        <img class="b3" src="assets/mascot/mia-ok.png" alt="" />
      </div>

      <!-- L2 常驻 IP 角标：全片在线 -->
      <div id="ipmark"${PIP ? ' class="with-pip"' : ""} data-layout-ignore>
        <div class="mk-face">
          <img class="mk-img f0" src="assets/mascot/mia-smile.png" alt="" />
          <img class="mk-img f1" src="assets/mascot/mia-wink.png" alt="" />
          <img class="mk-img f2" src="assets/mascot/mia-laugh.png" alt="" />
        </div>
        <span class="mk-txt"><b>${esc(cfg.ipName || "米亚老师")}</b><i></i><b style="font-weight:600;color:#5B7091;font-size:18px">原创</b></span>
      </div>

${PIP ? `      <!-- 真人画中画：外层不带时间（视频不能嵌进带时间的容器），动画只加在外层 -->
      <div id="pip" data-layout-ignore>
        <div class="pip-glow"></div>
        <div class="pip-frame">
          <video id="pipv" class="clip" src="${esc(PIP.src)}" data-start="0" data-duration="${f3(DURATION)}"
                 data-media-start="${f3(PIP.mediaStart)}" data-track-index="2" muted playsinline></video>
        </div>
        <div class="pip-name"><b>${esc(cfg.ipName || "米亚老师")}</b><i></i><span>原创</span></div>
      </div>
` : ""}      <div id="topbar">
        <div id="brand"><span class="bdot"></span>${esc(cfg.brand || "")}</div>
        <div id="chapter">${esc(cfg.chapter || "")}</div>
      </div>
      <div id="toprule" data-layout-ignore></div>

${BASE ? [S1, S2, S3, S4, S5, S6].join("\n") : ""}
${sceneMarkup}

${captionHtml}

      <div id="progress-track" data-layout-ignore>
        <div id="progress-fill"></div>
        <div id="progress-dot"></div>
      </div>
    </div>

    <script>
try {
      const tl = gsap.timeline({ paused: true, defaults: { ease: "power2.out" } });
${L.join("\n")}
} catch (e) {
  document.title = "ERR:" + (e && e.message) + " | " + (e && e.stack ? e.stack.split(String.fromCharCode(10))[1] : "");
}
    </script>
  </body>
</html>
`;

/* ══════════════ 写盘 ══════════════ */
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, "index.html"), html);
fs.writeFileSync(
  path.join(OUT, "hyperframes.json"),
  JSON.stringify(
    {
      $schema: "https://hyperframes.heygen.com/schema/hyperframes.json",
      registry: "https://raw.githubusercontent.com/heygen-com/hyperframes/main/registry",
      paths: { blocks: "compositions", components: "compositions/components", assets: "assets" },
    },
    null,
    2
  )
);

console.log(`✔ 已生成 ${OUT}/index.html`);
console.log(`  画幅 ${W}×${H} ｜ 时长 ${DURATION}s ｜ 场景 ${(BASE ? 6 : 0) + SCENES2.length} ｜ 字幕 ${captions.length} 行 / ${wordTotal} 词`);
console.log(`  时间线指令 ${L.length} 条`);
