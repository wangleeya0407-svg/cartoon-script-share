#!/usr/bin/env python3
"""
本地语音转写 + 智能断句（faster-whisper + 本地模型）
用法：
  python3 pipeline/transcribe.py <音频/视频> [--model models/faster-whisper-small] [--out talk/transcript]
产物：
  <out>.json  字幕行（start/end/text，已按口播节奏切好，可直接喂字幕条）
  <out>.srt   标准字幕文件
  <out>.txt   纯文本（方便人校对）
说明：纯本地运行，不联网。解码交给 FFmpeg（绕开新版 av 与 faster-whisper 的 API 不兼容）。
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import wave
from pathlib import Path

SAMPLE_RATE = 16000
PUNCT_BREAK = "，。？！；：、,.?!;:"
SENT_END = "。？！?!"

# 字幕行参数（中文口播）
# 软阈值：达到就在有标点时断；硬阈值：无论有无标点都断（仍优先等到标点，避免把词拆开）
SOFT_CHARS = 18       # 软上限字数（英文按 0.5 折算）
HARD_CHARS = 24       # 硬上限字数
MAX_SEC = 3.4         # 单行最长秒数
MIN_SEC = 0.45        # 单行最短秒数
PAUSE_BREAK = 0.28    # 停顿超过这个值就断行


def find_ffmpeg() -> str:
    for cand in (
        os.environ.get("FFMPEG_BIN"),
        shutil.which("ffmpeg"),
        os.path.expanduser("~/.npm-global/bin/ffmpeg"),
    ):
        if cand and Path(cand).exists():
            return cand
    try:
        prefix = subprocess.check_output(["npm", "prefix", "-g"], text=True).strip()
        p = Path(prefix) / "bin" / "ffmpeg"
        if p.exists():
            return str(p)
    except Exception:
        pass
    raise SystemExit("[错误] 找不到 ffmpeg，请确认已安装或在 PATH 中")


def load_audio_16k(media: str, workdir: str):
    import numpy as np

    ff = find_ffmpeg()
    wav = Path(workdir) / "asr_in.wav"
    subprocess.run(
        [ff, "-v", "error", "-i", media, "-vn", "-ac", "1", "-ar", str(SAMPLE_RATE),
         "-acodec", "pcm_s16le", "-y", str(wav)],
        check=True,
    )
    with wave.open(str(wav), "rb") as w:
        raw = w.readframes(w.getnframes())
    return np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0


def text_width(s: str) -> float:
    """中文字符按 1，英文/数字按 0.5 估算视觉宽度。"""
    w = 0.0
    for ch in s:
        w += 0.5 if ord(ch) < 128 else 1.0
    return w


def norm_word(t: str) -> str:
    """单词级别标点转换（保留标点本身，供逐词高亮渲染）。"""
    t = t.replace(",", "，").replace("?", "？").replace("!", "！")
    return re.sub(r"(?<=[\u4e00-\u9fff])\.", "。", t)


def normalize(txt: str) -> str:
    """中文字幕标点规范化：英文半角标点 → 中文全角。"""
    txt = re.sub(r"\s+", " ", txt).strip()
    txt = txt.replace(",", "，").replace("?", "？").replace("!", "！")
    # 英文句点只在非数字/非英文词尾时转中文句号，避免破坏 Codex 之类
    txt = re.sub(r"(?<=[\u4e00-\u9fff])\.", "。", txt)
    return txt.strip("，。、；：,. ;:")



def merge_latin(ws):
    """把被切碎的英文单词合并（Codex 常被拆成 C/ode/x）。"""
    LAT = r"[A-Za-z0-9'\-]+[，。？！,?.!]?"
    out = []
    for w in ws:
        t = w["t"]
        if out and re.fullmatch(LAT, t.strip() or "x"):
            prev = out[-1]
            if re.fullmatch(LAT, prev["t"].strip() or "x") and (w["s"] - prev["e"]) < 0.60:
                prev["t"] = prev["t"] + t
                prev["e"] = w["e"]
                continue
        out.append(dict(w))
    return out

def build_lines(words):
    """把词级时间戳聚合成自然的口播字幕行。"""
    lines = []
    cur = []

    def flush():
        nonlocal cur
        if not cur:
            return
        cur2 = merge_latin(cur)
        txt = normalize("".join(w["t"] for w in cur2))
        if txt:
            lines.append({
                "start": round(cur2[0]["s"], 3),
                "end": round(cur2[-1]["e"], 3),
                "text": txt,
                # 保留词级时间戳：逐词高亮字幕的燃料
                "words": [
                    {"t": norm_word(x["t"]), "s": round(x["s"], 3), "e": round(x["e"], 3)}
                    for x in cur2
                ],
            })
        cur = []

    for i, w in enumerate(words):
        tok = w["t"]
        if not cur and not tok.strip(PUNCT_BREAK + " \"'"):
            continue
        cur.append(w)

        nxt = words[i + 1] if i + 1 < len(words) else None
        span = cur[-1]["e"] - cur[0]["s"]
        width = text_width("".join(x["t"] for x in cur))

        end_punct = bool(tok) and tok[-1] in SENT_END
        soft_punct = bool(tok) and tok[-1] in PUNCT_BREAK
        long_pause = nxt is not None and (nxt["s"] - w["e"]) >= PAUSE_BREAK

        # 断行决策：
        # 1) 句末/句中标点 → 立刻断
        # 2) 长停顿 → 断（但太短就先攒着）
        # 3) 超软上限 → 继续等到标点；超硬上限或超时长 → 强制断
        should = False
        if end_punct or soft_punct:
            should = True
        elif long_pause:
            should = not (span < MIN_SEC and width < 5 and nxt is not None)
        elif width >= HARD_CHARS or span >= MAX_SEC:
            should = True
        elif width >= SOFT_CHARS and nxt is None:
            should = True

        if should:
            flush()

    flush()

    # 合并一闪而过的极短行
    merged = []
    for ln in lines:
        if merged:
            prev = merged[-1]
            is_short = (ln["end"] - ln["start"]) < 0.55 or text_width(ln["text"]) < 4
            if is_short and text_width(prev["text"] + ln["text"]) <= SOFT_CHARS + 4:
                prev["text"] += ln["text"]
                prev["end"] = ln["end"]
                prev["words"] = (prev.get("words") or []) + (ln.get("words") or [])
                continue
        merged.append(dict(ln))

    # 用词级数据重新对齐文本，保证「整行文字」与「逐词 span」完全一致
    out = []
    for ln in merged:
        ws = ln.get("words") or []
        if ws:
            ln["text"] = normalize("".join(w["t"] for w in ws))
        if ln.get("text"):
            out.append(ln)
    return out


def fmt_srt(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("media")
    ap.add_argument("--model", default="models/faster-whisper-small")
    ap.add_argument("--out", default="talk/transcript")
    ap.add_argument("--lang", default="zh")
    args = ap.parse_args()

    model_dir = Path(args.model).resolve()
    if not (model_dir / "model.bin").exists():
        print(f"[错误] 模型不完整：{model_dir}/model.bin 不存在", file=sys.stderr)
        return 2
    if not Path(args.media).exists():
        print(f"[错误] 媒体文件不存在：{args.media}", file=sys.stderr)
        return 2

    with tempfile.TemporaryDirectory() as td:
        print("[1/4] 解码音频（FFmpeg → 16k 单声道）…", flush=True)
        audio = load_audio_16k(args.media, td)
        dur = len(audio) / SAMPLE_RATE
        print(f"      时长 {dur:.2f}s", flush=True)

        from faster_whisper import WhisperModel

        print(f"[2/4] 加载模型 {model_dir.name} …", flush=True)
        model = WhisperModel(str(model_dir), device="cpu", compute_type="int8")

        print("[3/4] 转写中（词级时间戳）…", flush=True)
        segments, info = model.transcribe(
            audio,
            language=args.lang,
            beam_size=5,
            vad_filter=True,
            vad_parameters=dict(min_silence_duration_ms=250),
            initial_prompt="以下是普通话口播内容，请用简体中文并加标点符号。",
            condition_on_previous_text=False,
            word_timestamps=True,
        )

        words = []
        for s in segments:
            for w in (s.words or []):
                t = (w.word or "").strip()
                if not t:
                    continue
                words.append({"t": t, "s": float(w.start), "e": float(w.end)})

    lines = build_lines(words)

    out_base = Path(args.out)
    out_base.parent.mkdir(parents=True, exist_ok=True)

    payload = {
        "source": Path(args.media).name,
        "model": model_dir.name,
        "language": info.language,
        "language_probability": round(float(info.language_probability), 4),
        "duration": round(dur, 3),
        "lines": lines,
        "full_text": "".join(l["text"] for l in lines),
    }
    out_base.with_suffix(".json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    srt = []
    for i, ln in enumerate(lines, 1):
        srt.append(f"{i}\n{fmt_srt(ln['start'])} --> {fmt_srt(ln['end'])}\n{ln['text']}\n")
    out_base.with_suffix(".srt").write_text("\n".join(srt), encoding="utf-8")
    out_base.with_suffix(".txt").write_text(
        "\n".join(ln["text"] for ln in lines), encoding="utf-8"
    )

    print(f"[4/4] 完成：{len(lines)} 行字幕", flush=True)
    for ln in lines:
        print(f"  [{ln['start']:6.2f} → {ln['end']:6.2f}] {ln['text']}")
    print(f"\n  {out_base.with_suffix('.json')}")
    print(f"  {out_base.with_suffix('.srt')}")
    print(f"  {out_base.with_suffix('.txt')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
