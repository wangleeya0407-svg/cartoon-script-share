#!/usr/bin/env python3
"""
t2s.py — 把转写结果里的繁体统一成简体

为什么需要：
  faster-whisper 在长音频上会把后半段输出成繁体（本课第 20–98 行整段繁体），
  字幕里繁简混排非常难看，也不利于后续专有名词规则匹配。先做一次归一，
  再做术语校正，顺序不能反。

用法：
  python3 pipeline/t2s.py talk/course.json --out talk/course-cn.json
"""

import argparse
import json
import sys

try:
    from zhconv import convert
except ImportError:
    sys.exit("✖ 缺少依赖：pip3 install zhconv -i https://mirrors.aliyun.com/pypi/simple/")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    data = json.load(open(args.src, encoding="utf-8"))
    changed = 0

    for line in data.get("lines", []):
        t = line.get("text", "")
        c = convert(t, "zh-cn")
        if c != t:
            changed += 1
            line["text"] = c
        for w in line.get("words", []):
            t = w.get("t", "")
            c = convert(t, "zh-cn")
            if c != t:
                w["t"] = c

    if "full_text" in data:
        data["full_text"] = convert(data["full_text"], "zh-cn")

    json.dump(data, open(args.out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"✔ {args.out}  行数 {len(data.get('lines', []))} ｜ 繁体行归一 {changed}")


if __name__ == "__main__":
    main()
