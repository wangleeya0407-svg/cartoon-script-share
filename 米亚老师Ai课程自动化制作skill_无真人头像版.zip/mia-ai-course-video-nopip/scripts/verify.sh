#!/bin/bash
# 成片验收：ffprobe 参数核对 + 从成片 mp4 抽帧（不依赖网络）
#
# 用法：
#   bash verify.sh <课程slug> <成片mp4> [时长下限秒数]
#   bash verify.sh api-course api-course/API入门课_成片.mp4 110
#
# 为什么不用 pipeline/verify.mjs：它底层走网络，断网时 502 / ENETUNREACH。
# ffprobe 查 duration / size / codec / 分辨率 / 帧数，结论同样可靠。
set -e

SLUG="${1:?用法: bash verify.sh <课程slug> <成片mp4> [时长秒数]}"
MP4="${2:?缺少成片路径}"
EXPECT="${3:-}"

if [ ! -f "$MP4" ]; then
  echo "✗ 找不到 $MP4"
  exit 1
fi

echo "▶ 参数核对"
ffprobe -v error -show_entries format=duration,size,bit_rate \
  -show_entries stream=codec_type,codec_name,width,height,r_frame_rate,nb_frames \
  -of default=noprint_wrappers=0 "$MP4"

D=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$MP4")
A=$(ffprobe -v error -select_streams a -show_entries stream=codec_name -of csv=p=0 "$MP4")
echo
echo "  时长 ${D}s ｜ 音轨 ${A:-无}"

if [ -z "$A" ]; then
  echo "  ✗ 没有音轨！回查 course-fix 的 --audio 参数（相对合成目录）"
  exit 1
fi

if [ -n "$EXPECT" ]; then
  DIFF=$(python3 -c "print(round(abs(float('$D') - float('$EXPECT')), 2))")
  OK=$(python3 -c "print('yes' if abs($D - $EXPECT) < 0.6 else 'no')")
  if [ "$OK" = "yes" ]; then
    echo "  ✔ 时长与预期一致（差 ${DIFF}s）"
  else
    echo "  ✗ 时长不符：成片 ${D}s，预期 ${EXPECT}s（差 ${DIFF}s）"
    exit 1
  fi
fi

# 抽帧：均匀取 8 个点 + 首帧和尾帧
OUT=".verify-$SLUG"
rm -rf "$OUT"; mkdir -p "$OUT"
LAST=$(python3 -c "print(round(max(0.3, float('$D') - 0.6), 1))")
BODY=$(python3 - "$D" <<'PY'
import sys
d = float(sys.argv[1])
# 跳过最前面 1 秒（封面已单独抽），后面均匀 6 个点
pts = [round(1.2 + (d - 2.0) * i / 6, 1) for i in range(6)]
print(" ".join(str(p) for p in pts))
PY
)
echo
echo "▶ 从成片抽帧"
for t in 1.2 $BODY $LAST; do
  ffmpeg -v error -ss "$t" -i "$MP4" -frames:v 1 -q:v 2 -y "$OUT/f_$t.jpg"
done
ls -1 "$OUT"

cat <<TIP

✔ 抽帧完成，逐张看这几件事（check 查不出来的）：
  · 首帧是不是完整封面（页眉 / IP 角标 / 大图 / 底纹 / 字幕都在，没有淡入）
  · 有没有整屏空白或只剩一个小标题的时刻
  · 字幕是不是完整句子，有没有「还 / 要多」这种词中截断
  · 卡片 / 链条节点有没有文字溢出、两栏不等高、压字
  · 结尾卡有没有 IP 大图、签名、无黑帧
看完记得 rm -rf $OUT
TIP
