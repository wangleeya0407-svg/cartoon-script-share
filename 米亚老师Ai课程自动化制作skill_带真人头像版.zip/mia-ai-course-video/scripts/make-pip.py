#!/usr/bin/env python3
"""
make-pip.py — 把真人口播视频裁成「头肩特写」正方形小视频，给画中画小窗用。

自动找人脸（OpenCV，均匀抽 24 帧取中位数），以脸为中心裁一个正方形：
脸高 × zoom（默认 2.2）作为边长，脸中心放在画面 42% 高度处（头顶留一点空，下面带到肩膀）。
输出无声 H.264（声音由 voice.m4a 负责，保证口型同步），480×480，30fps。

用法：
  python3 make-pip.py <口播视频> --out <slug>/assets/pip.mp4
  python3 make-pip.py talk.mp4 --out pip.mp4 --zoom 3.0          # 拉远一点，多带手势
  python3 make-pip.py talk.mp4 --out pip.mp4 --crop 560:560:80:60 # 手动指定 w:h:x:y，跳过识别
"""
import argparse
import json
import statistics
import subprocess
import sys


def probe(path):
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-select_streams", "v:0",
        "-show_entries", "stream=width,height:format=duration", "-of", "json", path])
    j = json.loads(out)
    st = j["streams"][0]
    return int(st["width"]), int(st["height"]), float(j["format"]["duration"])


def detect_face(path, w, h, dur, samples=24):
    """返回 (x, y, w, h, 命中帧数)；没装 OpenCV / 没有人脸模型 / 识别不到，返回 None 走默认构图"""
    try:
        import os
        import cv2
        xml = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        if not os.path.exists(xml):
            return None
        casc = cv2.CascadeClassifier(xml)
        if casc.empty():
            return None
    except Exception:
        return None
    cap = cv2.VideoCapture(path)
    boxes = []
    for i in range(samples):
        cap.set(cv2.CAP_PROP_POS_MSEC, (dur * (i + 0.5) / samples) * 1000)
        ok, frame = cap.read()
        if not ok:
            continue
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = casc.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=6,
                                      minSize=(int(min(w, h) * 0.12),) * 2)
        if len(faces):
            boxes.append(max(faces, key=lambda f: f[2] * f[3]))  # 取最大的脸
    cap.release()
    if len(boxes) < 3:
        return None
    med = lambda k: statistics.median(b[k] for b in boxes)
    return med(0), med(1), med(2), med(3), len(boxes)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("--out", required=True)
    ap.add_argument("--size", type=int, default=480, help="输出边长，默认 480")
    ap.add_argument("--zoom", type=float, default=2.2, help="裁切边长 = 脸高 × zoom，越大越远")
    ap.add_argument("--crop", default="", help="手动 w:h:x:y，跳过人脸识别")
    a = ap.parse_args()

    w, h, dur = probe(a.src)
    if a.crop:
        cw, ch, cx, cy = map(int, a.crop.split(":"))
        how = "手动"
    else:
        f = detect_face(a.src, w, h, dur)
        if f:
            fx, fy, fw, fh, n = f
            side = int(min(fh * a.zoom, w, h))
            cx = int(fx + fw / 2 - side / 2)
            cy = int(fy + fh / 2 - side * 0.42)
            how = f"人脸识别（{n}/24 帧命中）"
        else:
            # 没识别到：按口播常见构图——人居中、脸在上部。
            # 竖屏取满宽做边长，从 5% 高度往下裁（头顶留空、带到肩膀）；横屏取高的 80%，水平居中
            if h >= w:
                side = w
                cx, cy = 0, int(h * 0.05)
            else:
                side = int(h * 0.8)
                cx, cy = (w - side) // 2, int(h * 0.04)
            how = "未做人脸识别（没装 opencv-python 或没识别到），按口播默认构图"
        cx = max(0, min(cx, w - side))
        cy = max(0, min(cy, h - side))
        cw = ch = side

    vf = f"crop={cw}:{ch}:{cx}:{cy},scale={a.size}:{a.size}:flags=lanczos,fps=30,format=yuv420p"
    subprocess.check_call([
        "ffmpeg", "-v", "error", "-i", a.src, "-an", "-vf", vf,
        "-c:v", "libx264", "-crf", "22", "-preset", "veryfast", "-movflags", "+faststart",
        "-y", a.out])
    print(f"✔ 画中画素材 {a.out}  {a.size}×{a.size} / {dur:.2f}s")
    print(f"  裁切 {cw}:{ch}:{cx}:{cy}（源 {w}×{h}，{how}）")
    print(f"  不满意就加 --zoom 3.0 拉远，或 --crop {cw}:{ch}:{cx}:{cy} 手动微调")


if __name__ == "__main__":
    sys.exit(main())
