#!/bin/bash
# 课程视频工程脚手架 —— 所有中间产物都放在 <slug>/ 内，整个目录可以直接搬走
#
# 用法：
#   bash scaffold_course.sh <课程slug> <音频或视频文件> ["章节标签"] ["课程标题"]
#
# 例：
#   bash scaffold_course.sh api-course ~/Downloads/API入门课.mp4 "第 05 讲 · API 入门" "什么叫 API"
#
# 产出：
#   <slug>/assets/{mascot/*.png, gsap.min.js, voice.m4a, pip.mp4（输入是视频时）}
#   <slug>/scenes.json   分镜表模板（人工改）
#   <slug>/run.sh        一条命令跑完 ①②③④
set -e

SKILL_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ $# -lt 2 ]; then
  echo "用法: bash scaffold_course.sh <课程slug> <音频或视频文件> [\"章节标签\"] [\"课程标题\"]"
  exit 1
fi

SLUG="$1"
SRC="$2"
CHAPTER="${3:-第 01 讲 · 课程}"
TITLE="${4:-课程标题}"

if [ ! -f "$SRC" ]; then
  echo "✗ 找不到输入文件: $SRC"
  exit 1
fi

echo "▶ 建工程 $SLUG/"
mkdir -p "$SLUG/assets"
cp -R "$SKILL_DIR/assets/mascot" "$SLUG/assets/"
cp "$SKILL_DIR/assets/gsap.min.js" "$SLUG/assets/"

# 音频：视频就抽轨，音频统一转 aac
EXT="$(echo "${SRC##*.}" | tr 'A-Z' 'a-z')"
echo "▶ 准备音轨"
ffmpeg -v error -i "$SRC" -vn -c:a aac -b:a 128k -y "$SLUG/assets/voice.m4a"

# 真人画中画：输入带画面就自动裁一条头肩圆窗素材（无声），视频里的人和声音天然同步
PIP_ARG=""
if ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 "$SRC" | grep -qv '^\(png\|mjpeg\)$'; then
  echo "▶ 检测到画面，生成真人画中画素材"
  python3 "$SKILL_DIR/scripts/make-pip.py" "$SRC" --out "$SLUG/assets/pip.mp4"
  PIP_ARG='--pip assets/pip.mp4'
fi

DUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$SLUG/assets/voice.m4a")
echo "  时长 ${DUR}s"

# 分镜模板
cat > "$SLUG/scenes.json" <<'JSON'
[
  { "id": "s1", "type": "punch", "instant": true, "start": 0, "end": 5.0,
    "ip": "mia-talk",
    "lines": [
      { "text": "小标题", "cls": "pw-kicker", "at": 0 },
      { "html": "主标题<em>强调</em>", "cls": "pw-line yes", "at": 0 },
      { "text": "一句话副标题", "cls": "pw-q", "at": 0 }
    ] }
]
JSON

# 校订稿模板（行号从 0 开始，转写有多少行就要覆盖多少行）
cat > "$SLUG/override-src.json" <<'JSON'
[
  { "i": 0, "text": "第一行改成正确的文案。" }
]
JSON

# 运行脚本
cat > "$SLUG/run.sh" <<RUNSH
#!/bin/bash
# 一条命令跑完 ①②③④：繁简归一 → 校订 → config → 合成页
# 前置：$SLUG/transcript.json 已由 transcribe.py 生成
set -e
cd "\$(dirname "\$0")"
SKILL_DIR="$SKILL_DIR"
DUR=$DUR

# ① 繁简归一
# 有 transcript.json（转写产物）才做繁简归一；用文字稿对齐（align-script.py）时直接产出 transcript-cn.json，跳过
if [ -f transcript.json ]; then
  python3 "\$SKILL_DIR/scripts/t2s.py" transcript.json --out transcript-cn.json
fi

# ② 校订稿（行号）→ 时间锚点校订表
node "\$SKILL_DIR/scripts/mkoverride.mjs" transcript-cn.json \\
  override-src.json --out override.json

# ③ 生成 config
node "\$SKILL_DIR/scripts/course-fix.mjs" transcript-cn.json \\
  --start 0 --end \$DUR \\
  --out config.json --out-dir . \\
  --audio assets/voice.m4a \\
  --override override.json \\
  --scenes scenes.json \\
  --base false \\
  --chapter "$CHAPTER" \\
  --title "$TITLE" \\
  --brand "米亚老师 AI 课程" $PIP_ARG >/dev/null

# ④ 生成 HyperFrames 合成页
node "\$SKILL_DIR/scripts/build-course.mjs" config.json
RUNSH
chmod +x "$SLUG/run.sh"

cat <<TIP

✔ 工程就绪：$SLUG/   （时长 ${DUR}s）

按顺序做：
  1) 转写
     python3 "$SKILL_DIR/scripts/transcribe.py" $SLUG/assets/voice.m4a --model small --out $SLUG/transcript
  2) 通读 $SLUG/transcript-cn.json（上一步产物转简后），写 $SLUG/override-src.json
     —— 每一行都要覆盖，漏一行就漏一句错字
  3) 按 references/scene-types.md 写 $SLUG/scenes.json，元素 at 直接对转写时间
  4) bash $SLUG/run.sh
  5) npx hyperframes check $SLUG --at 1.5,20,45 --snapshots   抽帧看画面
  6) bash "$SKILL_DIR/scripts/render.sh" $SLUG "课程名_成片.mp4"
  7) bash "$SKILL_DIR/scripts/verify.sh" $SLUG "$SLUG/课程名_成片.mp4" $DUR
TIP
